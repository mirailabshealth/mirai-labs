begin;
create table if not exists mirai_private.analytics_events (
 id uuid primary key, session_id uuid not null, kind text not null,
 page text not null, compound_id text, created_at timestamptz not null default now()
);
alter table mirai_private.analytics_events enable row level security;
create index if not exists analytics_session_time on mirai_private.analytics_events(session_id,created_at);
create index if not exists analytics_time on mirai_private.analytics_events(created_at);
revoke all on mirai_private.analytics_events from public,anon,authenticated;
create or replace function public.mirai_track(p_id uuid,p_session uuid,p_kind text,p_page text,p_compound text default null) returns void
language plpgsql security definer set search_path='' as $$
begin
 if p_id is null or p_session is null or p_kind is null or p_kind not in ('page_view','product_view','cart_add','request_sent') or p_page is null or p_page not in ('index','about','affiliates','contact','faq','guide','peptide','policies','portal','privacy','research-use-only','stack','terms') then return;end if;
 if p_compound is not null and not exists(select 1 from public.mirai_catalog where compound_id=p_compound and active) then return;end if;
 perform pg_advisory_xact_lock(hashtextextended(p_session::text,0));
 if (select count(*) from mirai_private.analytics_events where session_id=p_session and created_at>now()-interval '1 day')>=200 then return;end if;
 if (select count(*) from mirai_private.analytics_events where created_at>now()-interval '1 day')>=20000 then return;end if;
 insert into mirai_private.analytics_events(id,session_id,kind,page,compound_id) values(p_id,p_session,p_kind,p_page,p_compound) on conflict(id) do nothing;
end $$;
create or replace function public.mirai_owner_analytics() returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if not mirai_private.verified() or not mirai_private.is_admin() then raise exception 'Owner access required';end if;
 with o as (select * from public.mirai_orders where created_at>=now()-interval '30 days'),
 paid as (select * from public.mirai_orders where paid_at>=now()-interval '30 days' and status in ('paid','shipped','refunded') and not payment_review),
 e as (select * from mirai_private.analytics_events where created_at>=now()-interval '30 days'),
 sessions as (select session_id,bool_or(kind='cart_add') cart,bool_or(kind='request_sent') sent,max(created_at) last_seen from e group by session_id)
 select jsonb_build_object(
 'generated_at',now(),'period_days',30,
 'requests',(select count(*) from o),
 'paid_orders',(select count(*) from paid),
 'net_product_cents',coalesce((select sum(greatest(0,product_total_cents-coalesce(product_refunded_cents,0))) from paid),0),
 'refunded_product_cents',coalesce((select sum(coalesce(product_refunded_cents,0)) from paid),0),
 'pending_approval',(select count(*) from public.mirai_orders where status='requested'),
 'pending_payment',(select count(*) from public.mirai_orders where status='confirmed'),
 'sessions',(select count(*) from sessions),
 'page_views',(select count(*) from e where kind='page_view'),
 'cart_sessions',(select count(*) from sessions where cart),
 'request_sessions',(select count(*) from sessions where sent),
 'inactive_carts',(select count(*) from sessions where cart and not sent and last_seen<now()-interval '24 hours'),
 'daily',coalesce((select jsonb_agg(z order by day_label) from (select to_char(created_at at time zone 'America/New_York','YYYY-MM-DD') as day_label,count(*) filter(where kind='page_view') views,count(distinct session_id) sessions from e group by 1) z),'[]'::jsonb),
 'products',coalesce((select jsonb_agg(z order by views desc) from (select compound_id,count(*) filter(where kind='product_view') views,count(*) filter(where kind='cart_add') adds from e where compound_id is not null group by compound_id order by views desc limit 20) z),'[]'::jsonb),
 'affiliates',coalesce((select jsonb_agg(z order by net_product_cents desc) from (select referral_code,count(*) orders,sum(greatest(0,product_total_cents-coalesce(product_refunded_cents,0))) net_product_cents,coalesce(sum((select amount_cents from public.mirai_commissions c where c.order_id=paid.id and c.status<>'reversed')),0) commission_cents from paid where affiliate_id is not null group by referral_code) z),'[]'::jsonb)
 ) into result;return result;
end $$;
revoke all on function public.mirai_track(uuid,uuid,text,text,text) from public;
grant execute on function public.mirai_track(uuid,uuid,text,text,text) to anon,authenticated;
revoke all on function public.mirai_owner_analytics() from public,anon;
grant execute on function public.mirai_owner_analytics() to authenticated;
select cron.schedule('mirai-analytics-retention','17 4 * * *',$$delete from mirai_private.analytics_events where created_at<now()-interval '90 days'$$) where not exists(select 1 from cron.job where jobname='mirai-analytics-retention');
commit;
