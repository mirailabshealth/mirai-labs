-- Support is isolated from commerce: no order, stock or commission mutations.
begin;
create sequence mirai_private.support_number start 10001;
create table public.mirai_support_tickets (
 id uuid primary key default gen_random_uuid(),
 ticket_number text not null unique default ('SUP-'||nextval('mirai_private.support_number')),
 user_id uuid not null references auth.users(id),
 order_id uuid references public.mirai_orders(id),
 category text not null check(category in ('general','specs','order_change','payment','missing','incorrect','damaged','quality')),
 subject text not null check(length(subject) between 3 and 150),
 status text not null default 'open' check(status in ('open','in_review','resolved')),
 request_key uuid not null,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(user_id,request_key)
);
create table public.mirai_support_messages (
 id uuid primary key default gen_random_uuid(),
 ticket_id uuid not null references public.mirai_support_tickets(id),
 author_id uuid not null references auth.users(id),
 is_owner boolean not null,
 body text not null check(length(body) between 1 and 5000),
 request_key uuid not null,
 created_at timestamptz not null default now(),
 unique(author_id,request_key)
);
create index on public.mirai_support_tickets(user_id,updated_at desc);
create index on public.mirai_support_messages(ticket_id,created_at);
alter table public.mirai_support_tickets enable row level security;
alter table public.mirai_support_messages enable row level security;
revoke all on public.mirai_support_tickets,public.mirai_support_messages from anon,authenticated;
grant select on public.mirai_support_tickets,public.mirai_support_messages to authenticated;
create policy support_ticket_read on public.mirai_support_tickets for select to authenticated using(mirai_private.verified() and (user_id=auth.uid() or mirai_private.is_admin()));
create policy support_message_read on public.mirai_support_messages for select to authenticated using(exists(select 1 from public.mirai_support_tickets t where t.id=ticket_id and mirai_private.verified() and (t.user_id=auth.uid() or mirai_private.is_admin())));
create table mirai_private.support_emails (
 id uuid primary key default gen_random_uuid(),
 message_id uuid not null unique references public.mirai_support_messages(id),
 state text not null default 'pending' check(state in ('pending','processing','prepared','sending','sent','failed','skipped')),
 attempts int not null default 0, lease_token uuid, lease_until timestamptz,
 last_error text, created_at timestamptz not null default now(),sent_at timestamptz
);
alter table mirai_private.support_emails enable row level security;
revoke all on mirai_private.support_emails from public,anon,authenticated;
create function public.mirai_support_create(p_category text,p_subject text,p_body text,p_order uuid,p_key uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare t public.mirai_support_tickets;
begin
 if not mirai_private.verified() then raise exception 'Verify your email and sign in.';end if;
 -- Serialize per account so concurrent retries cannot duplicate tickets or bypass limits.
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,41004));
 select * into t from public.mirai_support_tickets where user_id=auth.uid() and request_key=p_key;
 if found then return to_jsonb(t);end if;
 if p_key is null or p_category is null or p_category not in ('general','specs','order_change','payment','missing','incorrect','damaged','quality') or coalesce(length(btrim(p_subject)),0) not between 3 and 150 or coalesce(length(btrim(p_body)),0) not between 1 and 5000 then raise exception 'Choose a topic, enter a subject (3–150 characters) and message (1–5000 characters).';end if;
 if p_order is not null and not exists(select 1 from public.mirai_orders where id=p_order and user_id=auth.uid()) then raise exception 'Choose an order belonging to your account.';end if;
 if (select count(*) from public.mirai_support_tickets where user_id=auth.uid() and created_at>now()-interval '1 hour')>=5 then raise exception 'Please reply to an existing ticket or try again in an hour.';end if;
 insert into public.mirai_support_tickets(user_id,order_id,category,subject,request_key) values(auth.uid(),p_order,p_category,btrim(p_subject),p_key) returning * into t;
 insert into public.mirai_support_messages(ticket_id,author_id,is_owner,body,request_key) values(t.id,auth.uid(),false,btrim(p_body),p_key);
 return to_jsonb(t);
end $$;
create function public.mirai_support_reply(p_ticket uuid,p_body text,p_key uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare t public.mirai_support_tickets; m public.mirai_support_messages; owner_reply boolean;
begin
 if not mirai_private.verified() then raise exception 'Verify your email and sign in.';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,41004));
 select * into t from public.mirai_support_tickets where id=p_ticket for update;
 if not found or not (t.user_id=auth.uid() or mirai_private.is_admin()) then raise exception 'Ticket unavailable.';end if;
 select * into m from public.mirai_support_messages where author_id=auth.uid() and request_key=p_key;
 if found then
  if m.ticket_id<>p_ticket then raise exception 'Request already used.';end if;
  return m.id;
 end if;
 if p_key is null or coalesce(length(btrim(p_body)),0) not between 1 and 5000 then raise exception 'Enter a message of 1–5000 characters.';end if;
 if (select count(*) from public.mirai_support_messages where author_id=auth.uid() and created_at>now()-interval '1 hour')>=30 then raise exception 'Message limit reached. Try again in an hour.';end if;
 owner_reply:=mirai_private.is_admin() and t.user_id<>auth.uid();
 insert into public.mirai_support_messages(ticket_id,author_id,is_owner,body,request_key) values(t.id,auth.uid(),owner_reply,btrim(p_body),p_key) returning * into m;
 update public.mirai_support_tickets set status=case when owner_reply then 'in_review' else 'open' end,updated_at=now() where id=t.id;
 if owner_reply then insert into mirai_private.support_emails(message_id) values(m.id);end if;
 return m.id;
end $$;
create function public.mirai_support_status(p_ticket uuid,p_status text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 if p_status is null or p_status not in ('open','in_review','resolved') then raise exception 'Invalid ticket status.';end if;
 update public.mirai_support_tickets set status=p_status,updated_at=now() where id=p_ticket;
 if not found then raise exception 'Ticket unavailable.';end if;
end $$;
create function public.mirai_support_email_activity(p_ticket uuid) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 return coalesce((select jsonb_agg(jsonb_build_object('state',e.state,'created_at',e.created_at,'sent_at',e.sent_at,'error',e.last_error) order by e.created_at desc) from mirai_private.support_emails e join public.mirai_support_messages m on m.id=e.message_id where m.ticket_id=p_ticket),'[]'::jsonb);
end $$;
-- Separate, one-use email capabilities. The endpoint never accepts a caller-supplied recipient.
create function mirai_private.dispatch_support_emails() returns void language plpgsql security definer set search_path='' as $$
declare j record; token uuid;
begin
 update mirai_private.support_emails set state='failed',last_error='Delivery outcome uncertain. Check Gmail Sent; do not blindly resend.' where state='sending' and lease_until<now();
 update mirai_private.support_emails set state='failed',last_error='Delivery could not start after three attempts.' where state in ('processing','prepared') and lease_until<now() and attempts>=3;
 for j in select id from mirai_private.support_emails where attempts<3 and (state='pending' or (state in ('processing','prepared') and lease_until<now())) order by created_at for update skip locked limit 5 loop
  token:=gen_random_uuid();
  update mirai_private.support_emails set state='processing',attempts=attempts+1,lease_token=token,lease_until=now()+interval '5 minutes' where id=j.id;
  perform net.http_post(url:='https://qymwaujpaxbmeohcmueh.supabase.co/functions/v1/support-email',headers:='{"Content-Type":"application/json"}'::jsonb,body:=jsonb_build_object('job_id',j.id,'token',token),timeout_milliseconds:=60000);
 end loop;
end $$;
create function public.mirai_support_email_take(p_job uuid,p_token uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare j mirai_private.support_emails; result jsonb;
begin
 select * into j from mirai_private.support_emails where id=p_job and lease_token=p_token and state='processing' and lease_until>now() for update;
 if not found then return null;end if;
 select jsonb_build_object('email',u.email,'ticket_number',t.ticket_number) into result from public.mirai_support_messages m join public.mirai_support_tickets t on t.id=m.ticket_id join auth.users u on u.id=t.user_id where m.id=j.message_id and m.is_owner and u.email_confirmed_at is not null;
 if result is null then
  update mirai_private.support_emails set state='skipped',lease_token=null,lease_until=null,last_error='Verified recipient unavailable.' where id=j.id;
  return jsonb_build_object('skipped',true);
 end if;
 update mirai_private.support_emails set state='prepared' where id=j.id;
 return result;
end $$;
create function public.mirai_support_email_start(p_job uuid,p_token uuid) returns boolean language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.support_emails set state='sending',lease_until=now()+interval '5 minutes' where id=p_job and lease_token=p_token and state='prepared' and lease_until>now();
 return found;
end $$;
create function public.mirai_support_email_finish(p_job uuid,p_token uuid,p_sent boolean,p_error text) returns void language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.support_emails set state=case when p_sent then 'sent' else 'failed' end,sent_at=case when p_sent then now() else null end,last_error=case when p_sent then null else left(p_error,200) end,lease_token=null,lease_until=null where id=p_job and lease_token=p_token and ((p_sent and state='sending') or (not p_sent and state in ('prepared','sending')));
 if not found then raise exception 'Delivery lease invalid.';end if;
end $$;
revoke all on function public.mirai_support_create(text,text,text,uuid,uuid),public.mirai_support_reply(uuid,text,uuid),public.mirai_support_status(uuid,text),public.mirai_support_email_activity(uuid),mirai_private.dispatch_support_emails(),public.mirai_support_email_take(uuid,uuid),public.mirai_support_email_start(uuid,uuid),public.mirai_support_email_finish(uuid,uuid,boolean,text) from public,anon,authenticated;
grant execute on function public.mirai_support_create(text,text,text,uuid,uuid),public.mirai_support_reply(uuid,text,uuid),public.mirai_support_status(uuid,text),public.mirai_support_email_activity(uuid) to authenticated;
grant execute on function public.mirai_support_email_take(uuid,uuid),public.mirai_support_email_start(uuid,uuid),public.mirai_support_email_finish(uuid,uuid,boolean,text) to service_role;
select cron.schedule('mirai-support-email','* * * * *','select mirai_private.dispatch_support_emails();');
commit;
