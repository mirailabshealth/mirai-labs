begin;
-- Test-only identities exist only inside this transaction; no auth emails or deliveries.
insert into auth.users(id,aud,role,email,email_confirmed_at,created_at,updated_at) values
('10000000-0000-4000-8000-000000000001','authenticated','authenticated','support-test-a@example.invalid',now(),now(),now()),
('10000000-0000-4000-8000-000000000002','authenticated','authenticated','support-test-b@example.invalid',now(),now(),now()),
('10000000-0000-4000-8000-000000000003','authenticated','authenticated','support-test-unverified@example.invalid',null,now(),now());
do $$
declare t jsonb; t2 jsonb; mid uuid; k uuid:=gen_random_uuid(); replykey uuid:=gen_random_uuid(); jid uuid; tok uuid:=gen_random_uuid(); n int; other_order uuid:=gen_random_uuid();
begin
 perform set_config('request.jwt.claim.sub','',true);
 begin perform public.mirai_support_create('general','Test','Body',null,k);raise exception 'TEST FAIL anonymous';exception when others then if SQLERRM='TEST FAIL anonymous' then raise;end if;end;
 perform set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000003',true);
 begin perform public.mirai_support_create('general','Test','Body',null,k);raise exception 'TEST FAIL unverified';exception when others then if SQLERRM='TEST FAIL unverified' then raise;end if;end;
 perform set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000001',true);
 t:=public.mirai_support_create('general','Test support','<script>literal input</script>',null,k);
 t2:=public.mirai_support_create('general','Test support','Same retry',null,k);
 if t->>'id'<>t2->>'id' or t->>'ticket_number' not like 'SUP-%' then raise exception 'Duplicate ticket/number';end if;
 begin perform public.mirai_support_create('invalid','Test','Body',null,gen_random_uuid());raise exception 'TEST FAIL category';exception when others then if SQLERRM='TEST FAIL category' then raise;end if;end;
 begin perform public.mirai_support_create('general','Test',' ',null,gen_random_uuid());raise exception 'TEST FAIL empty';exception when others then if SQLERRM='TEST FAIL empty' then raise;end if;end;
 begin perform public.mirai_support_create('general','Test',repeat('x',5001),null,gen_random_uuid());raise exception 'TEST FAIL length';exception when others then if SQLERRM='TEST FAIL length' then raise;end if;end;
 begin perform public.mirai_support_create('general','Test','Body',other_order,gen_random_uuid());raise exception 'TEST FAIL foreign order';exception when others then if SQLERRM='TEST FAIL foreign order' then raise;end if;end;
 begin perform public.mirai_support_status((t->>'id')::uuid,'resolved');raise exception 'TEST FAIL customer status';exception when others then if SQLERRM='TEST FAIL customer status' then raise;end if;end;
 perform set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000002',true);
 begin perform public.mirai_support_reply((t->>'id')::uuid,'Unauthorized',gen_random_uuid());raise exception 'TEST FAIL foreign reply';exception when others then if SQLERRM='TEST FAIL foreign reply' then raise;end if;end;
 execute 'set local role authenticated';
 select count(*) into n from public.mirai_support_tickets;
 if n<>0 then raise exception 'RLS exposed other tickets';end if;
 select count(*) into n from public.mirai_support_messages;
 if n<>0 then raise exception 'RLS exposed other messages';end if;
 execute 'reset role';
 perform set_config('request.jwt.claim.sub','55a14f89-b637-4b77-bb59-e55e4e85326d',true);
 mid:=public.mirai_support_reply((t->>'id')::uuid,'Owner reply',replykey);
 if mid<>public.mirai_support_reply((t->>'id')::uuid,'Owner retry',replykey) then raise exception 'Duplicate reply';end if;
 if (select count(*) from mirai_private.support_emails where message_id=mid)<>1 then raise exception 'Duplicate/missing email';end if;
 if (select status from public.mirai_support_tickets where id=(t->>'id')::uuid)<>'in_review' then raise exception 'Owner reply status';end if;
 perform public.mirai_support_status((t->>'id')::uuid,'resolved');
 execute 'set local role authenticated';
 if not exists(select 1 from public.mirai_support_tickets where id=(t->>'id')::uuid) then raise exception 'Owner cannot see ticket';end if;
 execute 'reset role';
 select id into jid from mirai_private.support_emails where message_id=mid;
 update mirai_private.support_emails set state='processing',lease_token=tok,lease_until=now()+interval '5 minutes' where id=jid;
 if public.mirai_support_email_take(jid,gen_random_uuid()) is not null then raise exception 'Wrong token accepted';end if;
 if public.mirai_support_email_take(jid,tok)->>'email'<>'support-test-a@example.invalid' then raise exception 'Wrong recipient';end if;
 if public.mirai_support_email_take(jid,tok) is not null then raise exception 'Replay accepted';end if;
 if not public.mirai_support_email_start(jid,tok) then raise exception 'Start failed';end if;
 if public.mirai_support_email_start(jid,tok) then raise exception 'Repeated send accepted';end if;
 perform public.mirai_support_email_finish(jid,tok,true,null);
 perform set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000001',true);
 perform public.mirai_support_reply((t->>'id')::uuid,'Follow-up',gen_random_uuid());
 if (select status from public.mirai_support_tickets where id=(t->>'id')::uuid)<>'open' then raise exception 'Customer did not reopen';end if;
 if has_table_privilege('authenticated','public.mirai_support_messages','INSERT') or has_table_privilege('anon','public.mirai_support_tickets','SELECT') or has_function_privilege('authenticated','public.mirai_support_email_take(uuid,uuid)','EXECUTE') then raise exception 'Excess privileges';end if;
 execute 'set local role authenticated';
 if not exists(select 1 from public.mirai_support_tickets where id=(t->>'id')::uuid) then raise exception 'Customer cannot see own ticket';end if;
 execute 'reset role';
end $$;
rollback;
select 'PASS: anonymous/unverified blocked; validation; ticket/reply deduplication; cross-account RLS and reply denial; owner reply/status; email recipient, one-use token and send protection; customer reopen; service-only email APIs. All test data rolled back; no emails sent.' as result;
