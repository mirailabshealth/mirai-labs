begin;
select set_config('request.jwt.claim.sub','55a14f89-b637-4b77-bb59-e55e4e85326d',true);
do $$
declare jid uuid:=gen_random_uuid();token uuid:=gen_random_uuid();v jsonb;oid uuid; key uuid:=gen_random_uuid(); address jsonb:='{"name":"Test Recipient","line1":"123 Test Street","city":"Orlando","region":"FL","postal_code":"32801","country":"US"}'; items jsonb:='[{"compound_id":"retatrutide","vial_size":"20 mg/vial","quantity":1}]';
begin
 if has_function_privilege('anon','public.mirai_owner_email_take(uuid,uuid)','execute') or has_function_privilege('authenticated','public.mirai_owner_email_take(uuid,uuid)','execute') then raise exception 'Public claim privilege';end if;
 insert into mirai_private.commerce_jobs(id,kind,dedupe,state,lease_token,lease_until) values(jid,'owner_order_email_test','test:'||jid,'processing',token,now()+interval '5 minutes');
 if public.mirai_owner_email_take(jid,gen_random_uuid()) is not null then raise exception 'Forged token accepted';end if;
 v:=public.mirai_owner_email_take(jid,token);
 if v->>'email'<>'mirai.labs.health@gmail.com' or not (v->>'test')::boolean then raise exception 'Unsafe recipient';end if;
 if public.mirai_owner_email_take(jid,token) is not null then raise exception 'Replay accepted';end if;
 if not public.mirai_owner_email_start(jid,token) then raise exception 'Start failed';end if;
 if public.mirai_owner_email_start(jid,token) then raise exception 'Double send allowed';end if;
 perform public.mirai_owner_email_finish(jid,token,true,null);
 if not exists(select 1 from mirai_private.commerce_jobs where id=jid and state='sent' and sent_at is not null and lease_token is null) then raise exception 'Completion failed';end if;
 perform public.mirai_save_profile('Test Recipient','4075550100',address,true);
 oid:=public.mirai_request_v2(items,'','Rollback notification test',key,address);
 if public.mirai_request_v2(items,'','Rollback notification test',key,address)<>oid then raise exception 'Duplicate request created order';end if;
 perform mirai_private.enqueue(oid,'owner_request',oid||':owner');
 perform mirai_private.enqueue(oid,'owner_request',oid||':owner');
 if (select count(*) from mirai_private.commerce_jobs where order_id=oid and kind='owner_request')<>1 then raise exception 'Duplicate owner alert';end if;
 select id into jid from mirai_private.commerce_jobs where order_id=oid and kind='owner_request';
 update mirai_private.commerce_jobs set state='processing',lease_token=token,lease_until=now()+interval '5 minutes' where id=jid;
 v:=public.mirai_owner_email_take(jid,token);
 if v->>'order_number' is null or v->>'email'<>'mirai.labs.health@gmail.com' then raise exception 'Missing order details';end if;
 update public.mirai_orders set status='cancelled' where id=oid;
 if public.mirai_owner_email_start(jid,token) then raise exception 'Cancelled after take sent';end if;
 update mirai_private.commerce_jobs set state='processing' where id=jid;
 v:=public.mirai_owner_email_take(jid,token);
 if not (v->>'skipped')::boolean then raise exception 'Cancelled not skipped';end if;
end $$;
-- pg_net sends only after commit; this rollback also discards queued test HTTP requests.
select mirai_private.dispatch_owner_order_emails();
rollback;
select 'PASS: owner-only recipient, private claims, forged/replayed tokens, dedupe, single SMTP start, completion, cancelled orders; no test orders or email created' as result;
