-- Owner alerts use existing queued owner_request jobs. No order/payment mutation.
begin;
create or replace function mirai_private.dispatch_owner_order_emails() returns void language plpgsql security definer set search_path='' as $$
declare j record; token uuid;
begin
 update mirai_private.commerce_jobs set state='failed',last_error='Delivery outcome uncertain. Check Gmail Sent before retrying.',lease_token=null,lease_until=null where kind in ('owner_request','owner_order_email_test') and state='sending' and lease_until<now();
 update mirai_private.commerce_jobs set state='failed',last_error='Email could not start after three attempts.',lease_token=null,lease_until=null where kind in ('owner_request','owner_order_email_test') and state in ('processing','prepared') and lease_until<now() and attempts>=3;
 update mirai_private.commerce_jobs queued set state='skipped',last_error='Order no longer awaiting approval.' where kind='owner_request' and state='pending' and not exists(select 1 from public.mirai_orders o where o.id=queued.order_id and o.status='requested');
 for j in select id from mirai_private.commerce_jobs where kind in ('owner_request','owner_order_email_test') and attempts<3 and available_at<=now() and (state='pending' or (state in ('processing','prepared') and lease_until<now())) order by created_at for update skip locked limit 5 loop
  token:=gen_random_uuid();
  update mirai_private.commerce_jobs set state='processing',attempts=attempts+1,lease_token=token,lease_until=now()+interval '5 minutes' where id=j.id;
  perform net.http_post(url:='https://qymwaujpaxbmeohcmueh.supabase.co/functions/v1/support-email',headers:='{"Content-Type":"application/json"}'::jsonb,body:=jsonb_build_object('job_id',j.id,'token',token,'kind','owner_request'),timeout_milliseconds:=60000);
 end loop;
end $$;
create or replace function public.mirai_owner_email_take(p_job uuid,p_token uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare j mirai_private.commerce_jobs; num text;
begin
 select * into j from mirai_private.commerce_jobs where id=p_job and kind in ('owner_request','owner_order_email_test') and lease_token=p_token and state='processing' and lease_until>now() for update;
 if not found then return null;end if;
 if j.kind='owner_request' then
  select order_number into num from public.mirai_orders where id=j.order_id and status='requested';
  if not found then
   update mirai_private.commerce_jobs set state='skipped',lease_token=null,lease_until=null,last_error='Order no longer awaiting approval.' where id=j.id;
   return jsonb_build_object('skipped',true);
  end if;
 end if;
 update mirai_private.commerce_jobs set state='prepared' where id=j.id;
 return jsonb_build_object('email','mirai.labs.health@gmail.com','order_number',num,'test',j.kind='owner_order_email_test');
end $$;
create or replace function public.mirai_owner_email_start(p_job uuid,p_token uuid) returns boolean language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.commerce_jobs j set state='sending',lease_until=now()+interval '5 minutes' where id=p_job and kind in ('owner_request','owner_order_email_test') and lease_token=p_token and state='prepared' and lease_until>now() and (kind='owner_order_email_test' or exists(select 1 from public.mirai_orders o where o.id=j.order_id and o.status='requested'));
 return found;
end $$;
create or replace function public.mirai_owner_email_finish(p_job uuid,p_token uuid,p_sent boolean,p_error text) returns void language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.commerce_jobs set state=case when p_sent then 'sent' else 'failed' end,sent_at=case when p_sent then now() else null end,last_error=case when p_sent then null else left(p_error,200) end,lease_token=null,lease_until=null where id=p_job and kind in ('owner_request','owner_order_email_test') and lease_token=p_token and ((p_sent and state='sending') or (not p_sent and state in ('prepared','sending')));
 if not found then raise exception 'Delivery lease invalid.';end if;
end $$;
revoke all on function mirai_private.dispatch_owner_order_emails(),public.mirai_owner_email_take(uuid,uuid),public.mirai_owner_email_start(uuid,uuid),public.mirai_owner_email_finish(uuid,uuid,boolean,text) from public,anon,authenticated;
grant execute on function public.mirai_owner_email_take(uuid,uuid),public.mirai_owner_email_start(uuid,uuid),public.mirai_owner_email_finish(uuid,uuid,boolean,text) to service_role;
select cron.schedule('mirai-owner-order-email','* * * * *','select mirai_private.dispatch_owner_order_emails();');
commit;
