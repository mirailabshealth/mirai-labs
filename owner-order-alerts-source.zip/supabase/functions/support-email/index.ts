// Private delivery capability: each request requires a one-use DB-minted job token.
// No caller can choose a recipient, amount, payment handle or email content.
import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import nodemailer from 'npm:nodemailer@^9';
const OWNER = 'mirai.labs.health@gmail.com';
const reply = (status: number, body: string) => new Response(body, {status});
Deno.serve(async (req) => {
  if (req.method !== 'POST') return reply(405, 'Method not allowed');
  let body;
  try { const text = await req.text(); if (text.length > 1024) return reply(413, 'Request too large'); body = JSON.parse(text); }
  catch { return reply(400, 'Invalid request'); }
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuid.test(body?.job_id ?? '') || !uuid.test(body?.token ?? '')) return reply(401, 'Unauthorized');
  if (body.kind !== undefined && body.kind !== 'owner_request') return reply(400, 'Invalid notification kind');
  const ownerAlert = body.kind === 'owner_request';
  const prefix = ownerAlert ? 'mirai_owner_email_' : 'mirai_support_email_';
  const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {auth:{persistSession:false,autoRefreshToken:false}});
  const {data: job, error} = await db.rpc(prefix+'take', {p_job:body.job_id,p_token:body.token});
  if (error) return reply(503, 'Delivery unavailable');
  if (!job) return reply(401, 'Invalid or consumed delivery token');
  if (job.skipped) return reply(200, 'Skipped stale notification');
  let transport: any;
  let sending = false;
  try {
    const password = Deno.env.get('MIRAI_SMTP_PASSWORD');
    if (!password) throw Error('CONFIG');
    const message = ownerAlert ? {subject:job.test ? 'Mirai Labs: owner order alerts are connected' : `Mirai Labs: order ${job.order_number} needs approval`, text:job.test ? `Owner order notifications are connected. New requests will email this address with an order number and a link to the owner portal.

This is a notification test only. No order was created, approved or paid.

https://mirailabshealth.github.io/mirai-labs/portal.html?view=admin` : `A new order request is awaiting your review.

Order: ${job.order_number}

Sign in to the owner portal and find this order under Order requests & fulfillment:
https://mirailabshealth.github.io/mirai-labs/portal.html?view=admin

Review the items, shipping details and available inventory before approving. Approval will trigger the existing payment-instructions email. This notification does not approve the order or confirm payment.

Mirai Labs`} : {subject:`Mirai Labs: reply to ${job.ticket_number}`, text:`Hello,\n\nMirai Labs has replied to support ticket ${job.ticket_number}. Sign in to read the reply and continue the conversation:\nhttps://mirailabshealth.github.io/mirai-labs/portal.html?view=support\n\nUse the Support tab and select ${job.ticket_number}. For your privacy, message details are only displayed in your account.\n\nThis support update does not approve an order or verify payment.\n\nMirai Labs\n${OWNER}`};
    transport = nodemailer.createTransport({host:'smtp.gmail.com',port:465,secure:true,auth:{user:OWNER,pass:password},connectionTimeout:15000,greetingTimeout:15000,socketTimeout:20000});
    await transport.verify();
    // Consume the delivery lease immediately before SMTP sending.
    const {data: valid, error: startError} = await db.rpc(prefix+'start', {p_job:body.job_id,p_token:body.token});
    if (startError) throw Error('START');
    if (!valid) return reply(200, 'Delivery no longer active');
    sending = true;
    const result = await transport.sendMail({from:`Mirai Labs <${OWNER}>`,to:job.email,replyTo:OWNER,subject:message.subject,text:message.text,messageId:`<mirai-${ownerAlert?'owner-order':'support'}-${body.job_id}@gmail.com>`});
    if (!result.accepted?.length) throw Error('SEND');
    const {error: finishError} = await db.rpc(prefix+'finish', {p_job:body.job_id,p_token:body.token,p_sent:true,p_error:null});
    if (finishError) return reply(503, 'Delivery needs owner review');
    return reply(200, 'Email accepted by SMTP server');
  } catch {
    // A timeout after SMTP begins is ambiguous; never automatically resend it.
    const safeError = sending ? 'Delivery outcome uncertain. Check Gmail Sent before retrying.' : 'Email configuration or connection failed before sending.';
    await db.rpc(prefix+'finish', {p_job:body.job_id,p_token:body.token,p_sent:false,p_error:safeError});
    return reply(503, 'Email delivery needs attention');
  } finally { transport?.close(); }
});
