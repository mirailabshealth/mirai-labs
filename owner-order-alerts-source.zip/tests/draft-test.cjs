const fs=require('fs'),assert=require('assert'),{JSDOM}=require('jsdom');
const src=fs.readFileSync('/workspace/scratch/a72500340f12/deploy/mirai-labs/portal.html','utf8');
const w=new JSDOM('',{url:'https://example.com',runScripts:'outside-only'}).window;
w.eval("let catalog=[{compound_id:'retatrutide',vial_size:'20 mg/vial',active:true}],cart=[],cartVersion=0,quote={old:true},requestKey='old';"+src.slice(src.indexOf('function importStackDraft()'),src.indexOf('async function renderClient()'))+";window.state=()=>({cart,quote,requestKey});window.reset=()=>{cart=[]};");
function draft(items,extra={}){w.localStorage.setItem('mirai_order_draft',JSON.stringify({version:1,created_at:Date.now(),items,...extra}));}
const row={compound_id:'retatrutide',vial_size:'20 mg/vial',quantity:1};
draft([row],{code:'TEST5'});assert.equal(w.importStackDraft().code,'TEST5');assert.equal(w.state().cart[0].quantity,1);assert.equal(w.state().cart[0].vial_size,'20 mg/vial');assert.equal(w.state().quote,null);assert.equal(w.state().requestKey,null);assert.equal(w.importStackDraft(),null);assert.equal(w.state().cart.length,1);
w.reset();for(const bad of [null,{...row,quantity:0},{...row,quantity:1.5},{...row,quantity:1000},{...row,vial_size:'wrong'}]){draft([row,bad]);assert(w.importStackDraft().error);assert.equal(w.state().cart.length,0);}
draft([row],{created_at:Date.now()-90000000});assert(w.importStackDraft().error);assert.equal(w.localStorage.getItem('mirai_order_draft'),null);
w.localStorage.setItem('mirai_order_draft','null');assert(w.importStackDraft().error);
assert(!fs.readFileSync('/workspace/scratch/a72500340f12/deploy/mirai-labs/stack.html','utf8').includes('formspree.io'));
console.log('PASS Reta 20mg 1-vial import, referral, no duplicate import, quote invalidation, invalid/expired/malformed drafts rejected atomically, legacy Formspree removed');
