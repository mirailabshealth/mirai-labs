begin;
select set_config('request.jwt.claim.sub','55a14f89-b637-4b77-bb59-e55e4e85326d',true);
do $$
declare a jsonb:='{"name":"Test Recipient","line1":"123 Test Street","city":"Orlando","region":"FL","postal_code":"32801","country":"US"}'; p jsonb; items jsonb; oid uuid;
begin
 p:=public.mirai_save_profile('Test Recipient','4075550100',a,true);
 if p->'profile'->'shipping_address'->>'organization' is distinct from '' then raise exception 'TEST FAIL missing organization';end if;
 perform public.mirai_save_profile('Test Recipient','4075550100',a||'{"organization":""}',true);
 begin perform public.mirai_save_profile('Test Recipient','',a,true);raise exception 'TEST FAIL phone';exception when others then if sqlerrm like 'TEST FAIL%' then raise;end if;end;
 begin perform public.mirai_save_profile('Test Recipient','4075550100',a-'line1',true);raise exception 'TEST FAIL address';exception when others then if sqlerrm like 'TEST FAIL%' then raise;end if;end;
 begin perform public.mirai_save_profile('Test Recipient','4075550100',a,false);raise exception 'TEST FAIL consent';exception when others then if sqlerrm like 'TEST FAIL%' then raise;end if;end;
 select jsonb_build_array(jsonb_build_object('compound_id',compound_id,'vial_size',vial_size,'quantity',1)) into items from public.mirai_catalog where active limit 1;
 oid:=public.mirai_request_v2(items,'','Rollback test',gen_random_uuid(),a);
 if not exists(select 1 from public.mirai_orders where id=oid and status='requested') then raise exception 'TEST FAIL request';end if;
 perform public.mirai_request_v2(items,'','Rollback test',gen_random_uuid(),a||'{"organization":""}');
end $$;
select 'PASS: missing and blank organization accepted; phone, address, consent still required; requests remain pending' as result;
rollback;
