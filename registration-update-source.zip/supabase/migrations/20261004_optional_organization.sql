-- Organization is optional. Phone, address, verified email and consent remain required.
begin;
create or replace function public.mirai_save_profile(p_name text,p_phone text,p_address jsonb,p_consent boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare k text; a jsonb:='{}';ph text:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
begin
 if not mirai_private.verified() then raise exception 'Verify your email and sign in first';end if;
 if p_consent is distinct from true then raise exception 'Research-use and policy acknowledgment required';end if;
 if length(btrim(coalesce(p_name,''))) not between 2 and 120 then raise exception 'Enter your full name';end if;
 if length(ph) not between 10 and 15 then raise exception 'Enter a valid phone number including area code';end if;
 if jsonb_typeof(p_address) is distinct from 'object' then raise exception 'Shipping address required';end if;
 foreach k in array array['name','line1','city','region','postal_code'] loop
  if length(btrim(coalesce(p_address->>k,''))) not between 1 and 200 then raise exception 'Complete all required shipping fields';end if;
  a:=a||jsonb_build_object(k,btrim(p_address->>k));
 end loop;
 if length(coalesce(p_address->>'organization',''))>200 then raise exception 'Organization is too long';end if;
 a:=a||jsonb_build_object('organization',btrim(coalesce(p_address->>'organization','')));
 if p_address->>'country' is distinct from 'US' then raise exception 'Only U.S. shipping is available';end if;
 if (a->>'postal_code') !~ '^[0-9]{5}(-[0-9]{4})?$' then raise exception 'Enter a five-digit ZIP code or ZIP+4';end if;
 if length(coalesce(p_address->>'line2',''))>200 then raise exception 'Address line is too long';end if;
 a:=a||jsonb_build_object('line2',btrim(coalesce(p_address->>'line2','')),'country','US');
 insert into public.mirai_profiles(user_id,display_name,phone,shipping_address,policy_accepted_at) values(auth.uid(),btrim(p_name),ph,a,now())
 on conflict(user_id) do update set display_name=excluded.display_name,phone=excluded.phone,shipping_address=excluded.shipping_address,policy_accepted_at=coalesce(mirai_profiles.policy_accepted_at,excluded.policy_accepted_at);
 return public.mirai_account(null);
end $$;
create or replace function public.mirai_request_v2(p_items jsonb,p_code text,p_notes text,p_request_key uuid,p_address jsonb) returns uuid language plpgsql security definer set search_path='' as $$
declare oid uuid;r text;
begin
 if not mirai_private.verified() then raise exception 'Verified account required.';end if;
 if jsonb_typeof(p_address) is distinct from 'object' or length(p_address::text)>3000 then raise exception 'Shipping address required.';end if;
 foreach r in array array['name','line1','city','region','postal_code','country'] loop
  if length(trim(coalesce(p_address->>r,''))) not between 1 and 200 then raise exception 'Complete all required shipping fields.';end if;
 end loop;
 if length(coalesce(p_address->>'organization',''))>200 then raise exception 'Organization is too long.';end if;
 if p_address->>'country'<>'US' then raise exception 'Only US shipping requests are supported at launch.';end if;
 -- Serialize retries of this user's request without trusting browser totals.
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(auth.uid()::text||p_request_key::text,0));
 select id into oid from public.mirai_orders where user_id=auth.uid() and request_key=p_request_key;
 if found then return oid;end if;
 oid:=public.mirai_request(p_items,p_code,p_notes,p_request_key);
 update public.mirai_orders set shipping_address=p_address,commission_bps=(select a.commission_bps from public.mirai_affiliates a where a.user_id=mirai_orders.affiliate_id) where id=oid;
 perform mirai_private.enqueue(oid,'request_received',oid||':received');perform mirai_private.enqueue(oid,'owner_request',oid||':owner');return oid;
end $$;
commit;
