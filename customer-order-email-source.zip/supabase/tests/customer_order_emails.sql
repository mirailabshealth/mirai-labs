-- Rollback-only: no emails or persistent customer/test orders.
begin;
insert into auth.users(id,email,email_confirmed_at,raw_app_meta_data,raw_user_meta_data,aud,role) values('00000000-0000-4000-8000-000000000721','notification-test@example.invalid',now(),'{}','{}','authenticated','authenticated');
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000721',true);
do $$
declare oid uuid;jid uuid;token uuid:=gen_random_uuid();v jsonb;num text;key uuid:=gen_random_uuid();address jsonb:='{"name":"Test Recipient","line1":"123 Test Street","city":"Orlando","region":"FL","postal_code":"32801","country":"US"}';items jsonb:='[{"compound_id":"retatrutide","vial_size":"20 mg/vial","quantity":1}]';
begin
 if has_function_privilege('anon','public.mirai_customer_email_take(uuid,uuid)','execute') or has_function_privilege('authenticated','public.mirai_customer_email_start(uuid,uuid)','execute') or has_function_privilege('authenticated','public.mirai_customer_email_finish(uuid,uuid,boolean,text)','execute') then raise exception 'Exposed delivery functions';end if;
 perform public.mirai_save_profile('Test Recipient','4075550100',address,true);
 oid:=public.mirai_request_v2(items,'','Rollback email test',key,address);
 if public.mirai_request_v2(items,'','Rollback email test',key,address)<>oid then raise exception 'Duplicate order';end if;
 perform mirai_private.enqueue(oid,'request_received',oid||':received');
 if (select count(*) from mirai_private.commerce_jobs where order_id=oid and kind='request_received')<>1 then raise exception 'Duplicate notification';end if;
 select order_number into num from public.mirai_orders where id=oid;
 select id into jid from mirai_private.commerce_jobs where order_id=oid and kind='request_received';
 update mirai_private.commerce_jobs set state='processing',lease_token=token,lease_until=now()+interval '5 minutes' where id=jid;
 if public.mirai_customer_email_take(jid,gen_random_uuid()) is not null then raise exception 'Forged token';end if;
 v:=public.mirai_customer_email_take(jid,token);
 if v->>'email'<>'notification-test@example.invalid' or v->>'order_number'<>num or v->>'kind'<>'request_received' then raise exception 'Wrong recipient/order';end if;
 if v ? 'shipping_address' or v ? 'notes' then raise exception 'Unnecessary private data';end if;
 if public.mirai_customer_email_take(jid,token) is not null then raise exception 'Token replay';end if;
 if not public.mirai_customer_email_start(jid,token) then raise exception 'Start failed';end if;
 if public.mirai_customer_email_start(jid,token) then raise exception 'Double SMTP start';end if;
 perform public.mirai_customer_email_finish(jid,token,true,null);
 if not exists(select 1 from mirai_private.commerce_jobs where id=jid and state='sent' and sent_at is not null and lease_token is null) then raise exception 'Finish failed';end if;
 -- Shipping eligibility and cancellation checks only; no payment is recorded.
 perform mirai_private.enqueue(oid,'shipped',oid||':shipped');
 select id into jid from mirai_private.commerce_jobs where order_id=oid and kind='shipped';
 update mirai_private.commerce_jobs set state='processing',lease_token=token,lease_until=now()+interval '5 minutes' where id=jid;
 v:=public.mirai_customer_email_take(jid,token);
 if not (v->>'skipped')::boolean then raise exception 'Unshipped order emailed';end if;
 update public.mirai_orders set status='shipped',tracking_number='TEST123',tracking_url='https://example.invalid/track/TEST123' where id=oid;
 update mirai_private.commerce_jobs set state='processing',lease_token=token,lease_until=now()+interval '5 minutes' where id=jid;
 v:=public.mirai_customer_email_take(jid,token);
 if v->>'tracking_number'<>'TEST123' or v->>'kind'<>'shipped' then raise exception 'Tracking missing';end if;
 update public.mirai_orders set payment_review=true where id=oid;
 if public.mirai_customer_email_start(jid,token) then raise exception 'Payment hold ignored';end if;
 update public.mirai_orders set payment_review=false where id=oid;
 if not public.mirai_customer_email_start(jid,token) then raise exception 'Shipping start failed';end if;
 perform public.mirai_customer_email_finish(jid,token,false,'Delivery outcome uncertain.');
 -- Expired sending leases must fail without retry; no pg_net requests in this test.
 update mirai_private.commerce_jobs set state='sending',lease_token=token,lease_until=now()-interval '1 minute' where id=jid;
 update mirai_private.commerce_settings set email_ready=false where id;
 perform mirai_private.dispatch_customer_order_emails();
 if not exists(select 1 from mirai_private.commerce_jobs where id=jid and state='failed' and lease_token is null) then raise exception 'Ambiguous send retried';end if;
end $$;
rollback;
select 'PASS: correct verified recipient/order, dedupe, forged/replayed tokens rejected, single send, tracking eligibility, payment hold, uncertain delivery not retried; rollback only' as result;
