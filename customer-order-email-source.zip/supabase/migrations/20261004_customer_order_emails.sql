-- Customer notifications only; existing approval, payment and shipping transitions unchanged.
begin;
-- Do not send delayed notifications for orders predating this feature.
update mirai_private.commerce_jobs set state='skipped',last_error='Predates customer email activation; not sent retroactively.' where kind in ('request_received','shipped') and state='pending';
create or replace function public.mirai_customer_email_take(p_job uuid,p_token uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare j mirai_private.commerce_jobs;o public.mirai_orders;recipient text;
begin
 select * into j from mirai_private.commerce_jobs where id=p_job and kind in ('request_received','shipped') and lease_token=p_token and state='processing' and lease_until>now() for update;
 if not found then return null;end if;
 select * into o from public.mirai_orders where id=j.order_id;
 if not found or not coalesce((select email_ready from mirai_private.commerce_settings where id),false) or (j.kind='request_received' and o.status<>'requested') or (j.kind='shipped' and (o.status<>'shipped' or o.payment_review or nullif(trim(o.tracking_number),'') is null or o.tracking_url !~ '^https://')) then
  update mirai_private.commerce_jobs set state='skipped',lease_token=null,lease_until=null,last_error='Order no longer eligible for this notification.' where id=j.id;
  return jsonb_build_object('skipped',true);
 end if;
 select email into recipient from auth.users where id=o.user_id and email_confirmed_at is not null and deleted_at is null;
 if recipient is null then
  update mirai_private.commerce_jobs set state='failed',lease_token=null,lease_until=null,last_error='Customer email is not verified.' where id=j.id;
  return jsonb_build_object('skipped',true);
 end if;
 update mirai_private.commerce_jobs set state='prepared' where id=j.id;
 -- Send only necessary notification data. No address, price, payment handles or customer notes.
 return jsonb_build_object('email',recipient,'kind',j.kind,'order_number',o.order_number,'tracking_number',case when j.kind='shipped' then o.tracking_number end,'tracking_url',case when j.kind='shipped' then o.tracking_url end);
end $$;
create or replace function public.mirai_customer_email_start(p_job uuid,p_token uuid) returns boolean language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.commerce_jobs j set state='sending',lease_until=now()+interval '5 minutes' where id=p_job and kind in ('request_received','shipped') and lease_token=p_token and state='prepared' and lease_until>now() and (select email_ready from mirai_private.commerce_settings where id) and exists(select 1 from public.mirai_orders o join auth.users u on u.id=o.user_id where o.id=j.order_id and u.email_confirmed_at is not null and u.deleted_at is null and ((j.kind='request_received' and o.status='requested') or (j.kind='shipped' and o.status='shipped' and not o.payment_review and nullif(trim(o.tracking_number),'') is not null and o.tracking_url ~ '^https://')));
 return found;
end $$;
create or replace function public.mirai_customer_email_finish(p_job uuid,p_token uuid,p_sent boolean,p_error text) returns void language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.commerce_jobs set state=case when p_sent then 'sent' else 'failed' end,sent_at=case when p_sent then now() else null end,last_error=case when p_sent then null else left(p_error,200) end,lease_token=null,lease_until=null where id=p_job and kind in ('request_received','shipped') and lease_token=p_token and ((p_sent and state='sending') or (not p_sent and state in ('prepared','sending')));
 if not found then raise exception 'Delivery lease invalid.';end if;
end $$;
create or replace function mirai_private.dispatch_customer_order_emails() returns void language plpgsql security definer set search_path='' as $$
declare j record;token uuid;
begin
 update mirai_private.commerce_jobs set state='failed',last_error='Delivery outcome uncertain. Check Gmail Sent before retrying.',lease_token=null,lease_until=null where kind in ('request_received','shipped') and state='sending' and lease_until<now();
 update mirai_private.commerce_jobs set state='failed',last_error='Email could not start after three attempts.',lease_token=null,lease_until=null where kind in ('request_received','shipped') and state in ('processing','prepared') and lease_until<now() and attempts>=3;
 if not coalesce((select email_ready from mirai_private.commerce_settings where id),false) then return;end if;
 for j in select id from mirai_private.commerce_jobs where kind in ('request_received','shipped') and attempts<3 and available_at<=now() and (state='pending' or (state in ('processing','prepared') and lease_until<now())) order by created_at for update skip locked limit 5 loop
  token:=gen_random_uuid();
  update mirai_private.commerce_jobs set state='processing',attempts=attempts+1,lease_token=token,lease_until=now()+interval '5 minutes' where id=j.id;
  perform net.http_post(url:='https://qymwaujpaxbmeohcmueh.supabase.co/functions/v1/support-email',headers:='{"Content-Type":"application/json"}'::jsonb,body:=jsonb_build_object('job_id',j.id,'token',token,'kind','customer_order'),timeout_milliseconds:=60000);
 end loop;
end $$;
revoke all on function mirai_private.dispatch_customer_order_emails(),public.mirai_customer_email_take(uuid,uuid),public.mirai_customer_email_start(uuid,uuid),public.mirai_customer_email_finish(uuid,uuid,boolean,text) from public,anon,authenticated;
grant execute on function public.mirai_customer_email_take(uuid,uuid),public.mirai_customer_email_start(uuid,uuid),public.mirai_customer_email_finish(uuid,uuid,boolean,text) to service_role;
-- Schedule separately only after the updated edge worker is deployed.
commit;
