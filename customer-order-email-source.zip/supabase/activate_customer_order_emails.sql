select cron.schedule('mirai-customer-order-email','* * * * *','select mirai_private.dispatch_customer_order_emails();');
