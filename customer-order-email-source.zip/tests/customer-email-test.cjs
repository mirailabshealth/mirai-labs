const fs=require('fs'),assert=require('assert'),vm=require('vm');
const source=fs.readFileSync('/workspace/scratch/a72500340f12/deploy/mirai-labs/supabase/functions/support-email/index.ts','utf8');
const fn=source.slice(source.indexOf('export function customerOrderMessage'),source.indexOf('const reply =')).replace('export function','function').replace('job: any','job');
const ctx={URL,OWNER:'mirai.labs.health@gmail.com'};vm.createContext(ctx);vm.runInContext(fn,ctx);
const request=ctx.customerOrderMessage({kind:'request_received',order_number:'MIR-10001'});assert(request.text.includes('Please do not send payment yet'));assert(request.subject.includes('MIR-10001'));assert(!request.text.includes('$mirailabshealth'));
const shipped=ctx.customerOrderMessage({kind:'shipped',order_number:'MIR-10001',tracking_number:'ABC123',tracking_url:'https://example.invalid/track/ABC123'});assert(shipped.text.includes('ABC123'));assert(shipped.text.includes('https://example.invalid/track/ABC123'));
for(const job of [{kind:'shipped',order_number:'MIR-10001',tracking_number:'ABC123',tracking_url:'javascript:alert(1)'},{kind:'shipped',order_number:'MIR-10001',tracking_number:'A\nB',tracking_url:'https://example.invalid/'},{kind:'unknown',order_number:'MIR-10001'},{kind:'request_received',order_number:'MIR-10001\nBcc: bad'}]) assert.throws(()=>ctx.customerOrderMessage(job));
assert(source.includes("body.kind !== 'customer_order'"));assert(source.includes("customerOrder ? 'mirai_customer_email_'"));assert(source.includes('No caller can choose a recipient'));
console.log('PASS: request wording/no early payment; order number; shipping tracking; invalid protocol/header injection rejected; existing worker branches retained.');
