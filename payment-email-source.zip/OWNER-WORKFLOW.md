# Owner inventory and manual order workflow

Open portal.html, sign in with the existing owner account, and select Owner.

1. Add actual stock under Inventory by batch. Record compound, vial size, lot, vial count, optional COA and expiry. Restocks/corrections use Adjust with a reason.
2. Review portal requests. Confirm shipping and tax, then Approve & reserve stock. Approval is all-or-nothing and excludes expired batches. Manual reservations remain held until payment or owner cancellation.
3. Contact the customer separately with the approved total and business payment instructions. No payment provider or order-email service is connected. Do not tell the customer an automated email has been sent.
4. Verify the deposit in the actual payment account. Enter method, transaction reference, and exact amount under Confirm received payment. A receipt screenshot alone is insufficient. The backend checks owner authorization, order approval, exact total and duplicate transaction references. This records a payment; it does not charge a customer.
5. Enter carrier tracking and mark shipped. Stock is removed from physical on-hand quantities when shipped; reservations keep paid stock unavailable beforehand.
6. Decline/cancel only unpaid requests to release held stock. Refunds, payment corrections and affiliate payout reconciliation require support until dedicated owner controls are added. Do not edit database rows directly to bypass accounting safeguards.

Affiliate commissions are based on the stored discounted product subtotal, excluding shipping/tax, at the rate snapshotted when the request was made. Recording the same payment twice does not create a second commission. Commissions remain pending under the configured 30-day hold. Automated release scheduling and affiliate payouts are not enabled in this release.

Public Formspree inquiries are separate from authenticated portal orders. Public registration remains closed. No live stock counts have been invented or seeded.

## Deployment

The migration supabase/migrations/20261002_inventory_workflow.sql is applied once after the existing portal foundation/access/catalog migrations. Tests in supabase/tests/inventory_workflow.sql are run with the new schema inside a transaction and rolled back.

The repository root inventory-workflow-source.zip preserves this release's migration, tests, and these instructions. Extract it into the repository root when moving to CLI-based development. The optional Stripe/email adapter files in the working checkout were not activated or included in this manual-only release.

Payment method labels are internal bookkeeping categories, not a claim that any named payment service approves this business. Public payment handles have not been configured.

## Approved-order payment email (2026-10-03)

The manual-payment-email function and 20261003_manual_payment_email.sql add a separate Gmail SMTP sender. The approval trigger queues exactly one manual_payment_instructions job per order. A database scheduler dispatches eligible jobs once per minute; delivery stays paused while commerce_settings.email_ready is false. Other existing notification kinds are not handled by this sender and remain inactive.

Payment recipients: Cash App $mirailabshealth and Venmo business @mirailabshealth, both Mirai Labs. Zelle is omitted until recipient details are provided. All totals come from the approved database order; codes and affiliate commissions are not shown in the email. The email asks the customer to reply with payment method and transaction reference. Owners must still verify the actual deposit and record it in the portal. No payment API or automatic deposit verification is enabled.

Required secret: MIRAI_SMTP_PASSWORD, the Gmail app password for mirai.labs.health@gmail.com. Save through Supabase Edge Function Secrets; never place it in repository files, SQL or chat. Gmail Auth SMTP settings are separate and do not populate Edge Function secrets.

Deploy manual-payment-email with gateway JWT verification off because it authenticates one-use, five-minute job capabilities issued only by the private database scheduler. Every RPC that consumes a capability is service-role-only. The worker cannot accept caller-chosen recipients, order details, totals or payment handles. Generic requests and token replays cannot send mail.

Before enabling customer emails, run an owner-only mirai_test_payment_email() request, inspect its delivery status and the TEST — DO NOT PAY message in the owner Gmail inbox. Set email_ready true only after the test is successful. This does not enable other commerce-worker adapters. Test jobs may run while customer delivery is paused.

Sent means accepted by Gmail's SMTP server; inbox arrival and bounces require checking Gmail. Failed/ambiguous deliveries must be inspected in Gmail Sent before a manual retry. There is no automatic resend after SMTP begins, preventing repeated payment requests on an uncertain network outcome. A customer could cancel/pay immediately after the final pre-send check; the portal remains the authoritative order status.

Inventory is still mandatory for approval; no stock is invented. Public registration remains closed. The template tests run with node supabase/tests/payment_email.mjs. Database capability tests in supabase/tests/manual_payment_email.sql roll back all fixtures and send no emails.
