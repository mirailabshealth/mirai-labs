export const OWNER = 'mirai.labs.health@gmail.com';
export const PORTAL = 'https://mirailabshealth.github.io/mirai-labs/portal.html';
export function paymentMessage(order: any, test = false) {
  const cash = (n: number) => {
    if (!Number.isSafeInteger(n) || n < 0) throw Error('Invalid approved amount');
    return `$${(n / 100).toFixed(2)}`;
  };
  if (!test && (order.status !== 'confirmed' || order.payment_reference || order.payment_review)) throw Error('Order is not awaiting payment');
  const lines = order.items.map((item: any) => {
    if (!Number.isSafeInteger(item.quantity) || item.quantity < 1) throw Error('Invalid quantity');
    return `${item.compound_id} | ${item.vial_size} | ${item.quantity} vial(s) | ${cash(item.total_cents)}`;
  });
  if (order.items.reduce((sum: number, item: any) => sum + item.total_cents, 0) !== order.product_total_cents) throw Error('Product total mismatch');
  const subtotal = cash(order.product_total_cents), shipping = cash(order.shipping_cents), tax = cash(order.tax_cents);
  const total = cash(order.product_total_cents + order.shipping_cents + order.tax_cents);
  const ref = test ? 'MIR-TEST' : String(order.order_number || order.id).toUpperCase();
  return {
    subject: `${test ? '[TEST — DO NOT PAY] ' : ''}Mirai Labs — approved order ${ref} — ${total}`,
    text: `${test ? 'TEST MESSAGE ONLY — NO PAYMENT IS DUE. This is a sample, not a real order.\n\n' : ''}Thank you for choosing Mirai Labs. Your order has been reviewed and approved.\n\nOrder number: ${ref}\n\n${lines.join('\n')}\n\nProducts: ${subtotal}\nShipping: ${shipping}\nTax: ${tax}\nTOTAL TO PAY: ${total}\n\nChoose ONE payment method and send the exact total once:\n\nCash App: $mirailabshealth\nRecipient: Mirai Labs\nhttps://cash.app/$mirailabshealth\n\nVenmo business profile: @mirailabshealth\nRecipient: Mirai Labs\nhttps://venmo.com/mirailabshealth\n\nREQUIRED PAYMENT NOTE: ${ref}. Copy this order number into the payment note. Confirm that the recipient is Mirai Labs before sending. Do not send a second payment if your portal still says awaiting payment.\n\nAfter paying, sign in to your client portal and submit your payment method and transaction reference under this order. Acknowledge the payment instructions to submit. If you forgot the order number in your payment note, reply to this email with your order number and transaction reference; do not pay again. Never email passwords, bank details or full card numbers. Mirai Labs will verify receipt directly in the payment account before marking your order paid and releasing it for fulfillment. A payment screenshot alone does not confirm receipt.\n\nView your order: ${PORTAL}\nQuestions? Reply to this email or contact ${OWNER}.\n\nAll sales are final once payment is verified and the order is accepted for fulfillment, subject to our policy exceptions and applicable law. Shipping, payment and refund policies: https://mirailabshealth.github.io/mirai-labs/policies.html\n\nFor research purposes only. Not for human or animal consumption. Not intended to diagnose, treat, cure, or prevent any disease.`
  };
}
