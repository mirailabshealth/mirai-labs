begin;
do $$
declare a uuid:=gen_random_uuid(); b uuid:=gen_random_uuid(); na text;nb text;
begin
 insert into public.mirai_orders(id,user_id,request_key,items,product_total_cents,shipping_cents,tax_cents) values(a,'55a14f89-b637-4b77-bb59-e55e4e85326d',gen_random_uuid(),'[]',100,0,0),(b,'55a14f89-b637-4b77-bb59-e55e4e85326d',gen_random_uuid(),'[]',100,0,0);
 select order_number into na from public.mirai_orders where id=a;select order_number into nb from public.mirai_orders where id=b;
 if na=nb or na not like 'MIR-%' then raise exception 'Number collision';end if;
 begin update public.mirai_orders set order_number='MIR-CHANGED' where id=a;raise exception 'TEST FAIL mutable';exception when others then if SQLERRM='TEST FAIL mutable' then raise;end if;end;
 update public.mirai_orders set status='confirmed' where id=a;
 perform set_config('request.jwt.claim.sub','ba7fed89-7ba5-454a-bf66-6315f8f6d67f',true);
 begin perform public.mirai_submit_payment(a,'cashapp','TEST-REF',true);raise exception 'TEST FAIL wrong user';exception when others then if SQLERRM='TEST FAIL wrong user' then raise;end if;end;
 perform set_config('request.jwt.claim.sub','55a14f89-b637-4b77-bb59-e55e4e85326d',true);
 begin perform public.mirai_submit_payment(a,'cashapp','TEST-REF',false);raise exception 'TEST FAIL acknowledgment';exception when others then if SQLERRM='TEST FAIL acknowledgment' then raise;end if;end;
 perform public.mirai_submit_payment(a,'cashapp','TEST-REF',true);
 perform public.mirai_submit_payment(a,'cashapp','TEST-REF',true);
 if (select count(*) from public.mirai_payment_submissions where order_id=a)<>1 then raise exception 'Duplicate report';end if;
 if not exists(select 1 from public.mirai_orders where id=a and status='confirmed' and payment_reference is null) then raise exception 'Report marked paid';end if;
 if exists(select 1 from public.mirai_commissions where order_id=a) then raise exception 'Report earned commission';end if;
end $$;
rollback;
select 'PASS: unique immutable numbers; owner-only customer reports; required acknowledgment; duplicate-safe; no paid status or commission. Fixtures rolled back.' as result;
