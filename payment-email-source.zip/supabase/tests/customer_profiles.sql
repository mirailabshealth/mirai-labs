begin;
do $$
declare a jsonb:='{"organization":"Test laboratory","name":"Test recipient","line1":"1 Test Street","city":"Kissimmee","region":"FL","postal_code":"34741","country":"US"}';v jsonb;o uuid:=gen_random_uuid();
begin
 perform set_config('request.jwt.claim.sub','',true);
 begin perform public.mirai_save_profile('Test name','4075550100',a,true);raise exception 'TEST FAIL anonymous';exception when others then if SQLERRM='TEST FAIL anonymous' then raise;end if;end;
 perform set_config('request.jwt.claim.sub','55a14f89-b637-4b77-bb59-e55e4e85326d',true);
 begin perform public.mirai_save_profile('Test name','12',a,true);raise exception 'TEST FAIL phone';exception when others then if SQLERRM='TEST FAIL phone' then raise;end if;end;
 begin perform public.mirai_save_profile('Test name','4075550100',a,false);raise exception 'TEST FAIL consent';exception when others then if SQLERRM='TEST FAIL consent' then raise;end if;end;
 begin perform public.mirai_save_profile('Test name','4075550100',a-'postal_code',true);raise exception 'TEST FAIL address';exception when others then if SQLERRM='TEST FAIL address' then raise;end if;end;
 v:=public.mirai_save_profile('Test name','(407) 555-0100',a,true);
 if v->'profile'->>'phone'<>'4075550100' or v->'profile'->'shipping_address'->>'city'<>'Kissimmee' then raise exception 'Save failed';end if;
 insert into public.mirai_orders(id,user_id,request_key,items,product_total_cents) values(o,auth.uid(),gen_random_uuid(),'[]',100);
 if (select contact_phone from public.mirai_orders where id=o)<>'4075550100' then raise exception 'Phone snapshot missing';end if;
 if has_table_privilege('anon','public.mirai_profiles','SELECT') then raise exception 'Anonymous profile read';end if;
end $$;
rollback;
select 'PASS: verified account required, phone/address/consent validated, saved address returned, order phone snapshotted, no anonymous profile access. All test data rolled back.' as result;
