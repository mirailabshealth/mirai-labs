begin;
insert into auth.users(id,email,email_confirmed_at,raw_app_meta_data,raw_user_meta_data,aud,role) values
('00000000-0000-4000-8000-000000000101','mirai-owner-test@example.invalid',now(),'{}','{}','authenticated','authenticated'),
('00000000-0000-4000-8000-000000000102','mirai-partner-test@example.invalid',now(),'{}','{}','authenticated','authenticated');
insert into mirai_private.administrators(user_id) values('00000000-0000-4000-8000-000000000101');
insert into public.mirai_affiliate_applications(user_id,profile_url,requested_code,statement) values('00000000-0000-4000-8000-000000000102','https://example.invalid','MIRAITEST','Temporary test');
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000101',true);
set local role authenticated;
do $$ declare id uuid; begin
 perform public.mirai_account('Temporary owner');
 perform public.mirai_review_affiliate('00000000-0000-4000-8000-000000000102',true,'MIRAITEST',2000);
 id:=public.mirai_request('[{"compound_id":"tesamorelin","vial_size":"20 mg/vial","quantity":10}]','MIRAITEST','','00000000-0000-4000-8000-000000000111');
 assert (select count(*) from public.mirai_commissions where order_id=id)=0,'Unpaid commission created';
 perform public.mirai_order_status(id,'confirmed');
 perform public.mirai_order_status(id,'paid');
 perform public.mirai_order_status(id,'paid');
 assert (select count(*) from public.mirai_commissions where order_id=id)=1,'Duplicate commission';
 assert (select amount_cents from public.mirai_commissions where order_id=id)=22800,'Expected 20% of $1140';
 perform public.mirai_order_status(id,'refunded');
 assert (select status from public.mirai_commissions where order_id=id)='reversed','Refund not reversed';
 perform public.mirai_review_affiliate('00000000-0000-4000-8000-000000000102',false,'',500);
 assert (select active from public.mirai_affiliates where code='MIRAITEST')=false,'Partner deactivation failed';
end $$;
reset role;
rollback;
select 'PASS: owner approval, 20% commission on final discounted product revenue, paid-only accrual, idempotent payment update, refund reversal and affiliate deactivation. Fixtures rolled back.' as result;
