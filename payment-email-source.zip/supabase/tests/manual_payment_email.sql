begin;
do $$
declare jid uuid:=gen_random_uuid();token uuid:=gen_random_uuid();v jsonb;
begin
 if has_function_privilege('anon','public.mirai_payment_email_take(uuid,uuid)','execute') or has_function_privilege('authenticated','public.mirai_payment_email_take(uuid,uuid)','execute') then raise exception 'Public claim privilege';end if;
 insert into mirai_private.commerce_jobs(id,kind,dedupe,state,lease_token,lease_until) values(jid,'payment_email_test','transactional-test:'||jid,'processing',token,now()+interval '5 minutes');
 if public.mirai_payment_email_take(jid,gen_random_uuid()) is not null then raise exception 'Invalid token accepted';end if;
 v:=public.mirai_payment_email_take(jid,token);
 if v->>'email'<>'mirai.labs.health@gmail.com' or not (v->>'test')::boolean then raise exception 'Unsafe test recipient';end if;
 if public.mirai_payment_email_take(jid,token) is not null then raise exception 'Token replay accepted';end if;
 if not public.mirai_payment_email_start(jid,token) then raise exception 'Start failed';end if;
 if public.mirai_payment_email_start(jid,token) then raise exception 'Duplicate SMTP start accepted';end if;
 perform public.mirai_payment_email_finish(jid,token,true,null);
 if not exists(select 1 from mirai_private.commerce_jobs where id=jid and state='sent' and sent_at is not null and lease_token is null) then raise exception 'Completion failed';end if;
end $$;
do $$
declare oid uuid:=gen_random_uuid();jid uuid;t uuid:=gen_random_uuid();v jsonb;
begin
 insert into public.mirai_orders(id,user_id,request_key,items,product_total_cents,shipping_cents,tax_cents) values(oid,'55a14f89-b637-4b77-bb59-e55e4e85326d',gen_random_uuid(),'[]',100,0,0);
 update public.mirai_orders set status='confirmed' where id=oid;
 update public.mirai_orders set status='confirmed' where id=oid;
 if (select count(*) from mirai_private.commerce_jobs where order_id=oid and kind='manual_payment_instructions')<>1 then raise exception 'Approval must queue exactly once';end if;
 select id into jid from mirai_private.commerce_jobs where order_id=oid and kind='manual_payment_instructions';
 update public.mirai_orders set status='cancelled' where id=oid;
 update mirai_private.commerce_jobs set state='processing',lease_token=t,lease_until=now()+interval '5 minutes' where id=jid;
 v:=public.mirai_payment_email_take(jid,t);
 if not (v->>'skipped')::boolean then raise exception 'Cancelled order notification was not skipped';end if;
end $$;
rollback;
select 'PASS: private claims, forged/replayed tokens, one-use SMTP start, completion, approval dedupe and cancellation; test data rolled back and no email sent' as result;
