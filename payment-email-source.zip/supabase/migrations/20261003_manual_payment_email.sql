-- Approval-triggered manual payment email. No payment collection or auto-confirmation.
begin;
create extension if not exists pg_net with schema extensions;
create extension if not exists pg_cron;
alter table mirai_private.commerce_jobs drop constraint commerce_jobs_state_check;
alter table mirai_private.commerce_jobs add constraint commerce_jobs_state_check check(state in ('pending','processing','prepared','sending','sent','failed','skipped'));
alter table mirai_private.commerce_jobs add column sent_at timestamptz;
create function mirai_private.queue_manual_payment_email() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if old.status='requested' and new.status='confirmed' and (select provider='manual' from mirai_private.commerce_settings where id) then
  perform mirai_private.enqueue(new.id,'manual_payment_instructions',new.id||':manual-payment-instructions');
 end if;
 return new;
end $$;
create trigger mirai_manual_payment_approved after update of status on public.mirai_orders for each row execute function mirai_private.queue_manual_payment_email();

-- pg_net submits only a job ID and a random, short-lived, single-use capability.
-- No customer address, SMTP password, service key or order content is in the HTTP job.
create function mirai_private.dispatch_payment_emails() returns void language plpgsql security definer set search_path='' as $$
declare j record;t uuid;ready boolean;
begin
 select email_ready into ready from mirai_private.commerce_settings where id;
 update mirai_private.commerce_jobs set state='failed',last_error='Delivery outcome uncertain. Check Gmail Sent before retrying.' where kind in ('manual_payment_instructions','payment_email_test') and state='sending' and lease_until<now();
 update mirai_private.commerce_jobs set state='failed',last_error='Delivery attempt limit reached before SMTP sending.' where kind in ('manual_payment_instructions','payment_email_test') and state in ('processing','prepared') and lease_until<now() and attempts>=8;
 for j in select id from mirai_private.commerce_jobs where kind in ('manual_payment_instructions','payment_email_test') and (ready or kind='payment_email_test') and attempts<8 and ((state='pending' and available_at<=now()) or (state in ('processing','prepared') and lease_until<now())) order by created_at for update skip locked limit 5 loop
  t:=gen_random_uuid();
  update mirai_private.commerce_jobs set state='processing',attempts=attempts+1,lease_token=t,lease_until=now()+interval '5 minutes',last_error=null where id=j.id;
  perform net.http_post(url:='https://qymwaujpaxbmeohcmueh.supabase.co/functions/v1/manual-payment-email',headers:='{"Content-Type":"application/json"}'::jsonb,body:=jsonb_build_object('job_id',j.id,'token',t),timeout_milliseconds:=60000);
 end loop;
end $$;
create function public.mirai_payment_email_take(p_job uuid,p_token uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare j mirai_private.commerce_jobs;o public.mirai_orders;recipient text;
begin
 select * into j from mirai_private.commerce_jobs where id=p_job and lease_token=p_token and state='processing' and lease_until>now() and kind in ('manual_payment_instructions','payment_email_test') for update;
 if not found then return null;end if;
 if j.kind='payment_email_test' then
  update mirai_private.commerce_jobs set state='prepared' where id=j.id;
  return jsonb_build_object('test',true,'email','mirai.labs.health@gmail.com','order',jsonb_build_object('id','TEST-ONLY-NO-PAYMENT-DUE','items',jsonb_build_array(jsonb_build_object('compound_id','Sample compound','vial_size','10 mg','quantity',3,'total_cents',15000)),'product_total_cents',15000,'shipping_cents',1000,'tax_cents',0));
 end if;
 select * into o from public.mirai_orders where id=j.order_id;
 if o.status<>'confirmed' or o.payment_reference is not null or o.payment_review or not (select email_ready from mirai_private.commerce_settings where id) then
  update mirai_private.commerce_jobs set state='skipped',lease_token=null,lease_until=null,last_error='Order no longer awaiting payment or email paused.' where id=j.id;
  return jsonb_build_object('skipped',true);
 end if;
 select email into recipient from auth.users where id=o.user_id and email_confirmed_at is not null;
 if recipient is null then
  update mirai_private.commerce_jobs set state='failed',lease_token=null,last_error='Customer email is not verified.' where id=j.id;
  return jsonb_build_object('skipped',true);
 end if;
 update mirai_private.commerce_jobs set state='prepared' where id=j.id;
 return jsonb_build_object('test',false,'email',recipient,'order',to_jsonb(o));
end $$;
create function public.mirai_payment_email_start(p_job uuid,p_token uuid) returns boolean language plpgsql security definer set search_path='' as $$
declare j mirai_private.commerce_jobs;
begin
 select * into j from mirai_private.commerce_jobs where id=p_job and lease_token=p_token and state='prepared' and lease_until>now() for update;
 if not found then return false;end if;
 if j.kind='manual_payment_instructions' and (not (select email_ready from mirai_private.commerce_settings where id) or not exists(select 1 from public.mirai_orders where id=j.order_id and status='confirmed' and payment_reference is null and not payment_review)) then
  update mirai_private.commerce_jobs set state='skipped',lease_token=null,lease_until=null where id=j.id;return false;
 end if;
 if j.kind not in ('manual_payment_instructions','payment_email_test') then return false;end if;
 update mirai_private.commerce_jobs set state='sending',lease_until=now()+interval '5 minutes' where id=j.id;
 return true;
end $$;
create function public.mirai_payment_email_finish(p_job uuid,p_token uuid,p_sent boolean,p_error text) returns void language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.commerce_jobs set state=case when p_sent then 'sent' else 'failed' end,sent_at=case when p_sent then now() else null end,last_error=case when p_sent then null else left(p_error,200) end,lease_token=null,lease_until=null
 where id=p_job and lease_token=p_token and ((p_sent and state='sending') or (not p_sent and state in ('prepared','sending'))) and kind in ('manual_payment_instructions','payment_email_test');
 if not found then raise exception 'Delivery lease is no longer valid';end if;
end $$;
-- Test destination is fixed to the owner. Clients cannot use this as an email relay.
create function public.mirai_test_payment_email() returns uuid language plpgsql security definer set search_path='' as $$
declare jid uuid;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required';end if;
 if exists(select 1 from mirai_private.commerce_jobs where kind='payment_email_test' and created_at>now()-interval '5 minutes') then raise exception 'Wait five minutes before requesting another test';end if;
 insert into mirai_private.commerce_jobs(kind,dedupe) values('payment_email_test','payment-test:'||gen_random_uuid()) returning id into jid;
 return jid;
end $$;
revoke all on function mirai_private.queue_manual_payment_email(),mirai_private.dispatch_payment_emails(),public.mirai_payment_email_take(uuid,uuid),public.mirai_payment_email_start(uuid,uuid),public.mirai_payment_email_finish(uuid,uuid,boolean,text),public.mirai_test_payment_email() from public,anon,authenticated;
grant execute on function public.mirai_payment_email_take(uuid,uuid),public.mirai_payment_email_start(uuid,uuid),public.mirai_payment_email_finish(uuid,uuid,boolean,text) to service_role;
grant execute on function public.mirai_test_payment_email() to authenticated;
-- Customer delivery remains paused until an owner test succeeds and is inspected.
select cron.schedule('mirai-manual-payment-email','* * * * *','select mirai_private.dispatch_payment_emails();');
commit;
