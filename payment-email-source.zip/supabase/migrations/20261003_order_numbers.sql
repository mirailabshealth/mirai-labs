begin;
create sequence mirai_private.order_number_seq start 10001;
alter table public.mirai_orders add column order_number text;
update public.mirai_orders set order_number='MIR-'||nextval('mirai_private.order_number_seq');
alter table public.mirai_orders alter column order_number set not null;
alter table public.mirai_orders add constraint mirai_order_number_unique unique(order_number);
create function mirai_private.assign_order_number() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if TG_OP='INSERT' then new.order_number:='MIR-'||nextval('mirai_private.order_number_seq');
 elsif new.order_number is distinct from old.order_number then raise exception 'Order number cannot change';end if;
 return new;
end $$;
create trigger mirai_order_number before insert or update on public.mirai_orders for each row execute function mirai_private.assign_order_number();
create table public.mirai_payment_submissions(
 order_id uuid primary key references public.mirai_orders(id),
 user_id uuid not null references auth.users(id),
 method text not null check(method in ('cashapp','venmo')),
 transaction_reference text not null check(length(transaction_reference) between 3 and 150),
 acknowledged_at timestamptz not null default now(),
 submitted_at timestamptz not null default now()
);
alter table public.mirai_payment_submissions enable row level security;
create policy payment_submission_read on public.mirai_payment_submissions for select to authenticated using(user_id=auth.uid() or mirai_private.is_admin());
revoke all on public.mirai_payment_submissions from anon,authenticated;
grant select on public.mirai_payment_submissions to authenticated;
create function public.mirai_submit_payment(p_order uuid,p_method text,p_reference text,p_acknowledged boolean) returns void language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;r text:=btrim(p_reference);
begin
 if auth.uid() is null then raise exception 'Sign in required';end if;
 select * into o from public.mirai_orders where id=p_order and user_id=auth.uid() for update;
 if not found then raise exception 'Order not found';end if;
 if o.status<>'confirmed' or o.payment_reference is not null or o.payment_review then raise exception 'Order is not awaiting payment';end if;
 if p_acknowledged is distinct from true then raise exception 'Acknowledge payment instructions';end if;
 if p_method is null or p_method not in ('cashapp','venmo') or r is null or length(r)<3 or length(r)>150 then raise exception 'Valid payment method and transaction reference required';end if;
 insert into public.mirai_payment_submissions(order_id,user_id,method,transaction_reference) values(o.id,auth.uid(),p_method,r)
 on conflict(order_id) do nothing;
 -- Customer report only: never changes order/payment/commission state.
end $$;
revoke all on function mirai_private.assign_order_number(),public.mirai_submit_payment(uuid,text,text,boolean) from public,anon,authenticated;
grant execute on function public.mirai_submit_payment(uuid,text,text,boolean) to authenticated;
commit;
