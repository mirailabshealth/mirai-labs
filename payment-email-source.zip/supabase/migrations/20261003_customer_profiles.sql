begin;
alter table public.mirai_profiles add column phone text,add column shipping_address jsonb,add column policy_accepted_at timestamptz;
create function public.mirai_save_profile(p_name text,p_phone text,p_address jsonb,p_consent boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare k text; a jsonb:='{}';ph text:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
begin
 if not mirai_private.verified() then raise exception 'Verify your email and sign in first';end if;
 if p_consent is distinct from true then raise exception 'Research-use and policy acknowledgment required';end if;
 if length(btrim(coalesce(p_name,''))) not between 2 and 120 then raise exception 'Enter your full name';end if;
 if length(ph) not between 10 and 15 then raise exception 'Enter a valid phone number including area code';end if;
 if jsonb_typeof(p_address) is distinct from 'object' then raise exception 'Shipping address required';end if;
 foreach k in array array['organization','name','line1','city','region','postal_code'] loop
  if length(btrim(coalesce(p_address->>k,''))) not between 1 and 200 then raise exception 'Complete all required shipping fields';end if;
  a:=a||jsonb_build_object(k,btrim(p_address->>k));
 end loop;
 if p_address->>'country' is distinct from 'US' then raise exception 'Only U.S. shipping is available';end if;
 if (a->>'postal_code') !~ '^[0-9]{5}(-[0-9]{4})?$' then raise exception 'Enter a five-digit ZIP code or ZIP+4';end if;
 if length(coalesce(p_address->>'line2',''))>200 then raise exception 'Address line is too long';end if;
 a:=a||jsonb_build_object('line2',btrim(coalesce(p_address->>'line2','')),'country','US');
 insert into public.mirai_profiles(user_id,display_name,phone,shipping_address,policy_accepted_at) values(auth.uid(),btrim(p_name),ph,a,now())
 on conflict(user_id) do update set display_name=excluded.display_name,phone=excluded.phone,shipping_address=excluded.shipping_address,policy_accepted_at=coalesce(mirai_profiles.policy_accepted_at,excluded.policy_accepted_at);
 return public.mirai_account(null);
end $$;
alter table public.mirai_orders add column contact_phone text;
create function mirai_private.require_customer_profile() returns trigger language plpgsql security definer set search_path='' as $$
declare p public.mirai_profiles;
begin
 select * into p from public.mirai_profiles where user_id=new.user_id;
 if p.phone is null or p.shipping_address is null or p.policy_accepted_at is null then raise exception 'Complete your phone, shipping address and acknowledgments in Account before ordering';end if;
 new.contact_phone:=p.phone;
 return new;
end $$;
create trigger mirai_complete_profile before insert on public.mirai_orders for each row execute function mirai_private.require_customer_profile();
revoke all on function public.mirai_save_profile(text,text,jsonb,boolean),mirai_private.require_customer_profile() from public,anon,authenticated;
grant execute on function public.mirai_save_profile(text,text,jsonb,boolean) to authenticated;
commit;
