-- Run after migration within the same rollback-only transaction.
insert into auth.users(id,email,email_confirmed_at,raw_app_meta_data,raw_user_meta_data,aud,role) values
('00000000-0000-4000-8000-000000000711','code-one@example.invalid',now(),'{}','{}','authenticated','authenticated'),
('00000000-0000-4000-8000-000000000712','code-two@example.invalid',now(),'{}','{}','authenticated','authenticated');
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000711',true);
set local role authenticated;
select public.mirai_apply('https://example.invalid/one',' Once_Code ','Test audience');
do $$begin
 assert (select requested_code from public.mirai_affiliate_applications where user_id=auth.uid())='ONCE_CODE','Normalization failed';
 begin perform public.mirai_apply('https://example.invalid/one','DIFFERENT','Test');raise exception 'Repeat accepted';
 exception when raise_exception then if sqlerrm<>'You have already submitted an application. Your chosen code cannot be changed.' then raise;end if;end;
end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000712',true);
set local role authenticated;
do $$begin
 begin perform public.mirai_apply('https://example.invalid/two','once_code','Test');raise exception 'Duplicate accepted';
 exception when raise_exception then if sqlerrm<>'That affiliate code is already taken. Choose another code.' then raise;end if;end;
 begin perform public.mirai_apply('https://example.invalid/two','!!','Test');raise exception 'Invalid accepted';
 exception when raise_exception then if sqlerrm<>'Use 3–24 letters, numbers, hyphens or underscores for your code.' then raise;end if;end;
end $$;
select public.mirai_apply('https://example.invalid/two','ANOTHER_CODE','Test');
reset role;
do $$begin
 begin update public.mirai_affiliate_applications set requested_code='EDITED' where user_id='00000000-0000-4000-8000-000000000711';raise exception 'Edit accepted';
 exception when raise_exception then if sqlerrm<>'Your affiliate code is permanent and cannot be changed.' then raise;end if;end;
 begin delete from mirai_private.affiliate_code_reservations where code='ONCE_CODE';raise exception 'Release accepted';
 exception when raise_exception then if sqlerrm<>'Affiliate code reservations are permanent.' then raise;end if;end;
end $$;
-- Exercise the existing owner approval path using an existing owner only in this transaction.
select set_config('request.jwt.claim.sub',(select user_id::text from mirai_private.administrators limit 1),true);
set local role authenticated;
do $$begin
 begin perform public.mirai_review_affiliate('00000000-0000-4000-8000-000000000711',true,'OWNER_EDIT',500);raise exception 'Owner override accepted';
 exception when raise_exception then if sqlerrm<>'The affiliate selected a permanent code. Approve their chosen code without changing it.' then raise;end if;end;
end $$;
select public.mirai_review_affiliate('00000000-0000-4000-8000-000000000711',true,'ONCE_CODE',2000);
select public.mirai_review_affiliate('00000000-0000-4000-8000-000000000711',false,'',500);
select public.mirai_review_affiliate('00000000-0000-4000-8000-000000000711',true,'ONCE_CODE',500);
reset role;
do $$begin
 assert (select code='ONCE_CODE' and active and commission_bps=500 from public.mirai_affiliates where user_id='00000000-0000-4000-8000-000000000711'),'Approval/reactivation/tier failed';
 begin update public.mirai_affiliates set code='NEW_CODE' where user_id='00000000-0000-4000-8000-000000000711';raise exception 'Active code edit accepted';
 exception when raise_exception then if sqlerrm<>'Your affiliate code is permanent and cannot be changed.' then raise;end if;end;
end $$;
set local role anon;
do $$begin
 begin perform public.mirai_apply('https://example.invalid','ANON','Test');raise exception 'Anonymous accepted';exception when insufficient_privilege then null;end;
end $$;
reset role;
select 'PASS: one-time code, case-insensitive uniqueness, invalid-code retry, immutable reservation, owner approval, reactivation, automatic tier preservation and anonymous denial; fixtures rolled back.' as result;
