begin;
-- One permanent reservation per account; uniqueness also protects concurrent claims.
create table mirai_private.affiliate_code_reservations (
 user_id uuid primary key references auth.users(id),
 code text not null unique check(code ~ '^[A-Z0-9_-]{3,24}$'),
 created_at timestamptz not null default now()
);
alter table mirai_private.affiliate_code_reservations enable row level security;
revoke all on mirai_private.affiliate_code_reservations from public,anon,authenticated;
-- Existing activated codes are authoritative. Abort on historical conflicts.
insert into mirai_private.affiliate_code_reservations(user_id,code) select user_id,code from public.mirai_affiliates;
insert into mirai_private.affiliate_code_reservations(user_id,code)
 select p.user_id,p.requested_code from public.mirai_affiliate_applications p
 where not exists(select 1 from mirai_private.affiliate_code_reservations r where r.user_id=p.user_id);
update public.mirai_affiliate_applications p set requested_code=r.code
 from mirai_private.affiliate_code_reservations r where r.user_id=p.user_id and p.requested_code<>r.code;

create function mirai_private.lock_affiliate_code() returns trigger
language plpgsql security definer set search_path='' as $$
declare chosen text; saved text;
begin
 if TG_TABLE_NAME='mirai_affiliates' then chosen:=upper(trim(new.code));else chosen:=upper(trim(new.requested_code));end if;
 if chosen is null or chosen !~ '^[A-Z0-9_-]{3,24}$' then raise exception 'Use 3–24 letters, numbers, hyphens or underscores for your code.';end if;
 if TG_OP='UPDATE' and new.user_id is distinct from old.user_id then raise exception 'An affiliate code cannot be transferred.';end if;
 insert into mirai_private.affiliate_code_reservations(user_id,code) values(new.user_id,chosen) on conflict do nothing;
 select code into saved from mirai_private.affiliate_code_reservations where user_id=new.user_id;
 if saved is null then raise exception 'That affiliate code is already taken. Choose another code.';end if;
 if saved<>chosen then raise exception 'Your affiliate code is permanent and cannot be changed.';end if;
 if TG_TABLE_NAME='mirai_affiliates' then new.code:=saved;else new.requested_code:=saved;end if;
 return new;
end $$;
create trigger mirai_application_code_once before insert or update on public.mirai_affiliate_applications
 for each row execute function mirai_private.lock_affiliate_code();
create trigger mirai_affiliate_code_once before insert or update on public.mirai_affiliates
 for each row execute function mirai_private.lock_affiliate_code();
create function mirai_private.protect_code_reservation() returns trigger language plpgsql set search_path='' as $$
begin raise exception 'Affiliate code reservations are permanent.';end $$;
create trigger mirai_code_reservation_immutable before update or delete on mirai_private.affiliate_code_reservations
 for each row execute function mirai_private.protect_code_reservation();
revoke all on function mirai_private.lock_affiliate_code(),mirai_private.protect_code_reservation() from public,anon,authenticated;

create or replace function public.mirai_apply(p_profile_url text,p_code text,p_statement text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not mirai_private.verified() then raise exception 'Please verify your email and sign in.';end if;
 if exists(select 1 from public.mirai_affiliate_applications where user_id=auth.uid()) then
  raise exception 'You have already submitted an application. Your chosen code cannot be changed.';
 end if;
 if p_profile_url is null or p_profile_url !~ '^https://' then raise exception 'Use an https profile URL.';end if;
 insert into public.mirai_affiliate_applications(user_id,profile_url,requested_code,statement)
 values(auth.uid(),p_profile_url,upper(trim(p_code)),p_statement);
end $$;

create or replace function public.mirai_review_affiliate(p_user_id uuid,p_approve boolean,p_code text,p_commission_bps integer default 500) returns void language plpgsql security definer set search_path='' as $$
declare chosen text;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 select requested_code into chosen from public.mirai_affiliate_applications where user_id=p_user_id for update;
 if not found then raise exception 'Application not found.';end if;
 if p_approve then
  if upper(trim(p_code)) is distinct from chosen then raise exception 'The affiliate selected a permanent code. Approve their chosen code without changing it.';end if;
  insert into public.mirai_affiliates(user_id,code,active,commission_bps) values(p_user_id,chosen,true,500)
  on conflict(user_id) do update set active=true;
 else update public.mirai_affiliates set active=false where user_id=p_user_id;end if;
 update public.mirai_affiliate_applications set status=case when p_approve then 'approved' else 'rejected' end,reviewed_at=now() where user_id=p_user_id;
 insert into mirai_private.audit_events(actor_id,action,record_id,details) values(auth.uid(),'affiliate_review',p_user_id::text,
 jsonb_build_object('approved',p_approve,'code',chosen,'commission_bps',(select commission_bps from public.mirai_affiliates where user_id=p_user_id),'tier_mode','automatic'));
end $$;
commit;
