const fs=require('fs'),assert=require('assert'),{JSDOM}=require('jsdom');
const root='/workspace/scratch/a72500340f12/deploy/mirai-labs/';const src=fs.readFileSync(root+'portal.html','utf8');const w=new JSDOM('<main id="workspace"></main>',{runScripts:'outside-only',url:'https://example.invalid/portal.html?view=affiliate'}).window;
Object.assign(w,{$:id=>w.document.getElementById(id),esc:v=>String(v??'').replaceAll('<','&lt;').replaceAll('>','&gt;'),money:c=>'$'+c/100,session:{user:{id:'test'}},query:async()=>[],loadAffiliateProgress:async()=>{}});
w.eval(src.slice(src.indexOf('async function renderAffiliate()'),src.indexOf('let ownerInventory=')));
(async()=>{
 w.rpc=async()=>({affiliate:null,application:null});await w.renderAffiliate();assert(w.document.querySelector('#code-permanent').required);assert(w.document.querySelector('#code').required);assert(w.document.body.textContent.includes('only once'));
 w.rpc=async()=>({affiliate:null,application:{status:'pending',requested_code:'<b>TEST</b>'}});await w.renderAffiliate();assert(w.document.body.textContent.includes('<b>TEST</b>'));assert(!w.document.querySelector('#code'));assert.equal(w.document.querySelectorAll('b').length,0);
 w.rpc=async()=>({affiliate:{active:true,code:'FIXED',commission_bps:500},application:null});await w.renderAffiliate();assert(w.document.querySelector('#partner-code').readOnly);assert(w.document.body.textContent.includes('cannot be changed or transferred'));
 assert(src.includes('name="approved-code" value="${esc(a.requested_code)}" readonly'));
 const publicHtml=fs.readFileSync(root+'affiliates.html','utf8');assert(!publicHtml.includes('formspree.io'));assert(publicHtml.includes('portal.html?view=affiliate'));assert(!publicHtml.includes('id="affiliate-form"'));
 console.log('PASS: required one-time acknowledgment, pending/active code display, escaped codes, read-only owner code and unified application route');
})().catch(e=>{console.error(e);process.exit(1)});
