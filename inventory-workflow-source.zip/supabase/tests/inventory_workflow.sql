-- Run inside a transaction; all fixtures must be rolled back.
insert into auth.users(id,email,email_confirmed_at,raw_app_meta_data,raw_user_meta_data,aud,role) values
('00000000-0000-4000-8000-000000000201','stock-owner@example.invalid',now(),'{}','{}','authenticated','authenticated'),
('00000000-0000-4000-8000-000000000202','stock-partner@example.invalid',now(),'{}','{}','authenticated','authenticated'),
('00000000-0000-4000-8000-000000000203','stock-outsider@example.invalid',now(),'{}','{}','authenticated','authenticated');
insert into mirai_private.administrators(user_id) values('00000000-0000-4000-8000-000000000201');
insert into public.mirai_affiliates(user_id,code,active,commission_bps) values('00000000-0000-4000-8000-000000000202','STOCKTEST',true,2000);
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000201',true);
create temporary table test_ids(k text primary key,id uuid);
grant all on test_ids to authenticated;
set local role authenticated;
do $$declare lot uuid;oid uuid;oid2 uuid;addr jsonb:='{"organization":"Test lab","name":"Test","line1":"Test street","city":"Test","region":"FL","postal_code":"00000","country":"US"}';begin
 perform public.mirai_account('Stock test');
 lot:=public.mirai_stock_receive('survodutide','10 mg/vial','ROLLBACK-TEST',10,'',null,2);
 insert into test_ids values('lot',lot);
 oid:=public.mirai_request_v2('[{"compound_id":"survodutide","vial_size":"10 mg/vial","quantity":10}]','STOCKTEST','','00000000-0000-4000-8000-000000000211',addr);
 assert oid=public.mirai_request_v2('[{"compound_id":"survodutide","vial_size":"10 mg/vial","quantity":10}]','STOCKTEST','','00000000-0000-4000-8000-000000000211',addr),'Request retry duplicated';
 assert (select product_total_cents from public.mirai_orders where id=oid)=86640,'Stacked discount wrong';
 insert into test_ids values('order',oid);
 begin perform public.mirai_manual_payment(oid,'zelle','not-approved',87640);raise exception 'Unapproved receipt';exception when others then if sqlerrm='Unapproved receipt' then raise;end if;end;
 begin perform public.mirai_order_status(oid,'paid');raise exception 'Legacy payment bypass';exception when others then if sqlerrm='Legacy payment bypass' then raise;end if;end;
end $$;
reset role;
-- Manual mode works without a connected provider or email service.
set local role authenticated;
do $$declare oid uuid:=(select id from test_ids where k='order');lot uuid:=(select id from test_ids where k='lot');oid2 uuid;begin
 perform public.mirai_approve_order(oid,1000,0);perform public.mirai_approve_order(oid,1000,0);
 assert (select (x->>'reserved')::integer from jsonb_array_elements(public.mirai_inventory()->'lots') x where x->>'id'=lot::text)=10,'Reservation wrong';
 begin perform public.mirai_stock_adjust(lot,-1,'Damage');raise exception 'Reserved stock removed';exception when others then if sqlerrm='Reserved stock removed' then raise;end if;end;
 oid2:=public.mirai_request_v2('[{"compound_id":"survodutide","vial_size":"10 mg/vial","quantity":1}]','','','00000000-0000-4000-8000-000000000212','{"organization":"Lab","name":"Test","line1":"Street","city":"City","region":"FL","postal_code":"00000","country":"US"}');
 begin perform public.mirai_approve_order(oid2,1000,0);raise exception 'Oversold stock';exception when others then if sqlerrm='Oversold stock' then raise;end if;end;
end $$;
do $$declare oid uuid:=(select id from test_ids where k='order');begin
 begin perform public.mirai_manual_payment(oid,'zelle','fixture-transaction',1);raise exception 'Wrong payment accepted';exception when others then if sqlerrm='Wrong payment accepted' then raise;end if;end;
 assert public.mirai_manual_payment(oid,'zelle','fixture-transaction',87640)='paid','Payment failed';
 assert public.mirai_manual_payment(oid,'zelle','fixture-transaction',87640)='duplicate','Duplicate payment';
 assert (select count(*) from public.mirai_commissions where order_id=oid)=1,'Duplicate commission';
 assert (select amount_cents from public.mirai_commissions where order_id=oid)=17328,'Commission includes shipping or wrong rate';
 assert (select status from public.mirai_commissions where order_id=oid)='pending','Commission hold missing';

 assert (select status from public.mirai_orders where id=oid)='paid','Expiry changed paid order';
end $$;
select public.mirai_ship_order((select id from test_ids where k='order'),'TEST123','https://example.invalid/tracking');
reset role;
do $$declare oid uuid:=(select id from test_ids where k='order');begin
 assert (select on_hand from mirai_private.stock_lots where id=(select id from test_ids where k='lot'))=0,'Shipping stock deduction wrong';
 perform public.mirai_refund_record('evt_refund',oid,'manual:zelle:fixture-transaction',86640);
 assert (select status from public.mirai_commissions where order_id=oid)='reversed','Refund commission not reversed';
 assert (select on_hand from mirai_private.stock_lots where id=(select id from test_ids where k='lot'))=0,'Refund incorrectly restocked';
 assert not has_function_privilege('authenticated','public.mirai_payment_received(text,uuid,text,text,integer,text)','EXECUTE'),'Public payment write';
 assert not has_table_privilege('authenticated','mirai_private.stock_lots','SELECT'),'Private stock readable';
end $$;
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000203',true);
set local role authenticated;
do $$begin
 begin perform public.mirai_manual_payment((select id from test_ids where k='order'),'zelle','outsider',87640);raise exception 'Outsider payment access';exception when others then if sqlerrm='Outsider payment access' then raise;end if;end;
 begin perform public.mirai_inventory();raise exception 'Outsider inventory access';exception when others then if sqlerrm='Outsider inventory access' then raise;end if;end;
 assert (select count(*) from public.mirai_orders where id=(select id from test_ids where k='order'))=0,'Other customer order exposed';
end $$;
reset role;
