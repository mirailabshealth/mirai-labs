-- Inventory and order workflow. Does not enable collection of live payments.
begin;
create table mirai_private.commerce_settings (
 id boolean primary key default true check(id), payments_ready boolean not null default false,
 email_ready boolean not null default false, provider text not null default 'manual',
 hold_hours integer not null default 24 check(hold_hours between 1 and 48),
 commission_hold_days integer not null default 30 check(commission_hold_days between 1 and 180)
);
insert into mirai_private.commerce_settings(id) values(true);
create table mirai_private.stock_lots (
 id uuid primary key default gen_random_uuid(), compound_id text not null,vial_size text not null,
 batch text not null check(length(trim(batch)) between 1 and 100), coa_url text not null default '' check(coa_url='' or coa_url ~ '^https://'),
 expires_on date, on_hand integer not null default 0 check(on_hand between 0 and 100000),
 low_stock integer not null default 5 check(low_stock between 0 and 100000),
 created_at timestamptz not null default now(),
 foreign key(compound_id,vial_size) references public.mirai_catalog(compound_id,vial_size), unique(compound_id,vial_size,batch)
);
create table mirai_private.stock_allocations (
 order_id uuid references public.mirai_orders(id), lot_id uuid references mirai_private.stock_lots(id),
 quantity integer not null check(quantity>0), state text not null check(state in ('held','committed','released','shipped')),
 primary key(order_id,lot_id)
);
create table mirai_private.stock_movements (
 id bigint generated always as identity primary key, lot_id uuid references mirai_private.stock_lots(id),
 delta integer not null, reason text not null,actor_id uuid, order_id uuid, created_at timestamptz not null default now()
);
create table mirai_private.commerce_jobs (
 id uuid primary key default gen_random_uuid(), order_id uuid references public.mirai_orders(id),
 kind text not null, dedupe text not null unique, state text not null default 'pending' check(state in ('pending','processing','sent','failed')),
 attempts integer not null default 0, available_at timestamptz not null default now(), lease_until timestamptz,
 lease_token uuid, last_error text, created_at timestamptz not null default now()
);
create table mirai_private.payment_events (
 event_id text primary key,order_id uuid not null references public.mirai_orders(id),kind text not null,created_at timestamptz not null default now()
);
alter table public.mirai_orders add column shipping_address jsonb;
alter table public.mirai_orders add column shipping_cents integer check(shipping_cents between 0 and 1000000);
alter table public.mirai_orders add column tax_cents integer check(tax_cents between 0 and 10000000);
alter table public.mirai_orders add column approved_at timestamptz;
alter table public.mirai_orders add column expires_at timestamptz;
alter table public.mirai_orders add column payment_url text;
alter table public.mirai_orders add column provider_session text unique;
alter table public.mirai_orders add column payment_reference text unique;
alter table public.mirai_orders add column payment_review boolean not null default false;
alter table public.mirai_orders add column paid_at timestamptz;
alter table public.mirai_orders add column commission_bps integer check(commission_bps between 500 and 2000);
alter table public.mirai_orders add column tracking_url text;
alter table public.mirai_orders add column tracking_number text;
alter table public.mirai_orders add column product_refunded_cents integer not null default 0 check(product_refunded_cents>=0);
alter table public.mirai_commissions add column payable_at timestamptz;
-- Keep existing manual order endpoint from bypassing stock or payment verification.
create or replace function public.mirai_order_status(p_order_id uuid,p_status text) returns void language plpgsql security definer set search_path='' as $$
begin raise exception 'Use the inventory approval workflow. Use the owner payment confirmation form.';end $$;

create function mirai_private.enqueue(p_order uuid,p_kind text,p_key text) returns void language sql security definer set search_path='' as $$
 insert into mirai_private.commerce_jobs(order_id,kind,dedupe) values(p_order,p_kind,p_key) on conflict(dedupe) do nothing
$$;
create function public.mirai_inventory() returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 return jsonb_build_object('settings',(select to_jsonb(s) from mirai_private.commerce_settings s),'lots',coalesce((select jsonb_agg(to_jsonb(t)) from (
 select l.*,coalesce(sum(a.quantity) filter(where a.state in ('held','committed')),0)::integer reserved,
 l.on_hand-coalesce(sum(a.quantity) filter(where a.state in ('held','committed')),0)::integer available
 from mirai_private.stock_lots l left join mirai_private.stock_allocations a on a.lot_id=l.id group by l.id order by l.compound_id,l.vial_size,l.created_at
 ) t),'[]'::jsonb),'movements',coalesce((select jsonb_agg(to_jsonb(m)) from (select * from mirai_private.stock_movements order by created_at desc,id desc limit 100)m),'[]'::jsonb),
 'jobs',coalesce((select jsonb_agg(to_jsonb(j)) from (select id,order_id,kind,state,attempts,last_error,created_at from mirai_private.commerce_jobs order by created_at desc limit 50)j),'[]'::jsonb));
end $$;
create function public.mirai_stock_receive(p_compound text,p_size text,p_batch text,p_quantity integer,p_coa text default '',p_expires date default null,p_threshold integer default 5) returns uuid language plpgsql security definer set search_path='' as $$
declare lid uuid;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 if p_quantity is null or p_quantity not between 1 and 100000 then raise exception 'Enter a positive whole vial count.';end if;
 perform 1 from public.mirai_catalog where compound_id=p_compound and vial_size=p_size for update;
 if not found then raise exception 'Unknown catalog size.';end if;
 insert into mirai_private.stock_lots(compound_id,vial_size,batch,on_hand,coa_url,expires_on,low_stock) values(p_compound,p_size,trim(p_batch),p_quantity,coalesce(p_coa,''),p_expires,p_threshold) returning id into lid;
 insert into mirai_private.stock_movements(lot_id,delta,reason,actor_id) values(lid,p_quantity,'Initial stock received',auth.uid());return lid;
end $$;
create function public.mirai_stock_adjust(p_lot uuid,p_delta integer,p_reason text) returns void language plpgsql security definer set search_path='' as $$
declare l mirai_private.stock_lots; reserved integer;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 if p_delta is null or p_delta=0 or abs(p_delta)>100000 or length(trim(coalesce(p_reason,''))) not between 3 and 500 then raise exception 'Enter a nonzero adjustment and a reason.';end if;
 select * into l from mirai_private.stock_lots where id=p_lot for update;if not found then raise exception 'Batch not found.';end if;
 select coalesce(sum(quantity),0) into reserved from mirai_private.stock_allocations where lot_id=p_lot and state in ('held','committed');
 if l.on_hand+p_delta<reserved then raise exception 'Cannot remove vials reserved for orders.';end if;
 update mirai_private.stock_lots set on_hand=on_hand+p_delta where id=p_lot;
 insert into mirai_private.stock_movements(lot_id,delta,reason,actor_id) values(p_lot,p_delta,trim(p_reason),auth.uid());
end $$;
create function public.mirai_request_v2(p_items jsonb,p_code text,p_notes text,p_request_key uuid,p_address jsonb) returns uuid language plpgsql security definer set search_path='' as $$
declare oid uuid;r text;
begin
 if not mirai_private.verified() then raise exception 'Verified account required.';end if;
 if jsonb_typeof(p_address) is distinct from 'object' or length(p_address::text)>3000 then raise exception 'Shipping address required.';end if;
 foreach r in array array['name','line1','city','region','postal_code','country','organization'] loop
  if length(trim(coalesce(p_address->>r,''))) not between 1 and 200 then raise exception 'Complete all required shipping and organization fields.';end if;
 end loop;
 if p_address->>'country'<>'US' then raise exception 'Only US shipping requests are supported at launch.';end if;
 -- Serialize retries of this user's request without trusting browser totals.
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(auth.uid()::text||p_request_key::text,0));
 select id into oid from public.mirai_orders where user_id=auth.uid() and request_key=p_request_key;
 if found then return oid;end if;
 oid:=public.mirai_request(p_items,p_code,p_notes,p_request_key);
 update public.mirai_orders set shipping_address=p_address,commission_bps=(select a.commission_bps from public.mirai_affiliates a where a.user_id=mirai_orders.affiliate_id) where id=oid;
 perform mirai_private.enqueue(oid,'request_received',oid||':received');perform mirai_private.enqueue(oid,'owner_request',oid||':owner');return oid;
end $$;
create function public.mirai_approve_order(p_order uuid,p_shipping integer,p_tax integer) returns void language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;s mirai_private.commerce_settings;r record;l record;needed integer;take_n integer;free_n integer;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 select * into s from mirai_private.commerce_settings where id;
 if s.provider<>'manual' and (not s.payments_ready or not s.email_ready) then raise exception 'Payment and email connections must be tested and enabled before approval.';end if;
 if p_shipping is null or p_tax is null or p_shipping<0 or p_tax<0 then raise exception 'Confirm shipping and tax amounts.';end if;
 select * into o from public.mirai_orders where id=p_order for update;
 if not found then raise exception 'Order not found.';end if;
 if o.status='confirmed' then return;end if;
 if o.status<>'requested' or o.shipping_address is null then raise exception 'Order requires a new request with a shipping address.';end if;
 for r in select * from jsonb_to_recordset(o.items) as x(compound_id text,vial_size text,quantity integer) order by compound_id,vial_size loop
  perform 1 from public.mirai_catalog where compound_id=r.compound_id and vial_size=r.vial_size and active for update;
  if not found then raise exception 'A requested size is no longer active.';end if;
  needed:=r.quantity;
  for l in select * from mirai_private.stock_lots where compound_id=r.compound_id and vial_size=r.vial_size and (expires_on is null or expires_on>current_date) order by expires_on nulls last,created_at,id for update loop
   select l.on_hand-coalesce(sum(quantity),0) into free_n from mirai_private.stock_allocations where lot_id=l.id and state in ('held','committed');
   take_n:=least(needed,free_n);
   if take_n>0 then insert into mirai_private.stock_allocations(order_id,lot_id,quantity,state) values(o.id,l.id,take_n,'held');needed:=needed-take_n;end if;
   exit when needed=0;
  end loop;
  if needed>0 then raise exception 'Insufficient available stock for % (%). No inventory was reserved.',r.compound_id,r.vial_size;end if;
 end loop;
 update public.mirai_orders set status='confirmed',shipping_cents=p_shipping,tax_cents=p_tax,approved_at=now(),expires_at=case when s.provider='manual' then null else now()+make_interval(hours=>s.hold_hours) end where id=o.id;
 if s.provider<>'manual' then perform mirai_private.enqueue(o.id,'create_payment',o.id||':payment');end if;
 insert into mirai_private.audit_events(actor_id,action,record_id) values(auth.uid(),'order_approved',o.id::text);
end $$;
create function public.mirai_cancel_order(p_order uuid) returns void language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 select * into o from public.mirai_orders where id=p_order for update;
 if not found or o.status not in ('requested','confirmed') or o.payment_reference is not null then raise exception 'Only unpaid requests can be declined.';end if;
 -- Confirmed sessions must be expired by the worker before releasing their inventory.
 if o.provider_session is not null then perform mirai_private.enqueue(o.id,'cancel_payment',o.id||':cancel');
 else update mirai_private.stock_allocations set state='released' where order_id=o.id and state='held';end if;
 update public.mirai_orders set status='cancelled',payment_url=null where id=o.id;
 perform mirai_private.enqueue(o.id,'cancelled',o.id||':cancelled');
end $$;
create function public.mirai_ship_order(p_order uuid,p_tracking text,p_url text) returns void language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;a record;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 if length(trim(coalesce(p_tracking,''))) not between 3 and 150 or coalesce(p_url,'') !~ '^https://' then raise exception 'Enter a tracking number and HTTPS carrier tracking link.';end if;
 select * into o from public.mirai_orders where id=p_order for update;
 if not found or o.status<>'paid' or o.payment_review then raise exception 'Only verified paid orders can be shipped.';end if;
 for a in select * from mirai_private.stock_allocations where order_id=o.id and state='committed' order by lot_id loop
  update mirai_private.stock_lots set on_hand=on_hand-a.quantity where id=a.lot_id;
  insert into mirai_private.stock_movements(lot_id,delta,reason,actor_id,order_id) values(a.lot_id,-a.quantity,'Order shipped',auth.uid(),o.id);
 end loop;
 update mirai_private.stock_allocations set state='shipped' where order_id=o.id and state='committed';
 update public.mirai_orders set status='shipped',tracking_number=trim(p_tracking),tracking_url=p_url where id=o.id;
 perform mirai_private.enqueue(o.id,'shipped',o.id||':shipped');
end $$;
-- Integration endpoints below are service-role-only; public clients cannot mark payments.
create function public.mirai_commerce_claim() returns jsonb language plpgsql security definer set search_path='' as $$
declare j mirai_private.commerce_jobs;o public.mirai_orders;token uuid:=gen_random_uuid();recipient text;
begin
 select * into j from mirai_private.commerce_jobs where (state='pending' and available_at<=now()) or (state='processing' and lease_until<now()) order by created_at for update skip locked limit 1;
 if not found then return null;end if;
 update mirai_private.commerce_jobs set state='processing',attempts=attempts+1,lease_until=now()+interval '5 minutes',lease_token=token where id=j.id;
 select * into o from public.mirai_orders where id=j.order_id;
 select email into recipient from auth.users where id=o.user_id;
 return jsonb_build_object('id',j.id,'token',token,'kind',j.kind,'attempts',j.attempts+1,'order',to_jsonb(o),'email',recipient,'settings',(select to_jsonb(s) from mirai_private.commerce_settings s));
end $$;
create function public.mirai_commerce_finish(p_job uuid,p_token uuid,p_error text default null) returns void language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.commerce_jobs set state=case when p_error is null then 'sent' when attempts>=8 then 'failed' else 'pending' end,
 last_error=left(p_error,1000),available_at=now()+interval '5 minutes',lease_until=null,lease_token=null where id=p_job and lease_token=p_token and state='processing';
 if not found then raise exception 'Job lease no longer valid.';end if;
end $$;
create function public.mirai_payment_link(p_order uuid,p_session text,p_url text) returns boolean language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;
begin
 if p_session is null or p_url !~ '^https://checkout[.]stripe[.]com/' then raise exception 'Invalid payment session.';end if;
 select * into o from public.mirai_orders where id=p_order for update;
 if o.status<>'confirmed' or o.expires_at<=now() then return false;end if;
 if o.provider_session is not null and o.provider_session<>p_session then raise exception 'Order already has a payment session.';end if;
 update public.mirai_orders set provider_session=p_session,payment_url=p_url where id=o.id;
 perform mirai_private.enqueue(o.id,'payment_link',o.id||':link');return true;
end $$;
create function public.mirai_payment_received(p_event text,p_order uuid,p_session text,p_payment text,p_cents integer,p_currency text) returns text language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;days_n integer;
begin
 select * into o from public.mirai_orders where id=p_order for update;
 if not found then raise exception 'Unknown order.';end if;
  if o.provider_session is distinct from p_session or p_currency<>'usd' or p_cents is distinct from o.product_total_cents+o.shipping_cents+o.tax_cents or coalesce(p_payment,'')='' then raise exception 'Payment does not match approved order.';end if;
 if o.payment_reference is not null then
  if o.payment_reference<>p_payment then raise exception 'Different payment already recorded.';end if;
  insert into mirai_private.payment_events values(p_event,o.id,'duplicate_paid',now()) on conflict(event_id) do nothing;return 'duplicate';
 end if;
 insert into mirai_private.payment_events values(p_event,o.id,'paid',now());
 if o.status<>'confirmed' then
  update public.mirai_orders set payment_review=true,payment_reference=p_payment,paid_at=now() where id=o.id;
  perform mirai_private.enqueue(o.id,'owner_payment_review',o.id||':review');return 'review_required';
 end if;
 update mirai_private.stock_allocations set state='committed' where order_id=o.id and state='held';
 update public.mirai_orders set status='paid',payment_reference=p_payment,paid_at=now(),payment_url=null where id=o.id;
 if o.affiliate_id is not null then
  if o.commission_bps is null then raise exception 'Missing snapshotted affiliate rate.';end if;
  select commission_hold_days into days_n from mirai_private.commerce_settings where id;
  insert into public.mirai_commissions(order_id,affiliate_id,eligible_revenue_cents,commission_bps,amount_cents,status,payable_at)
  values(o.id,o.affiliate_id,o.product_total_cents,o.commission_bps,round(o.product_total_cents*o.commission_bps::numeric/10000),'pending',now()+make_interval(days=>days_n));
 end if;
 perform mirai_private.enqueue(o.id,'receipt',o.id||':receipt');perform mirai_private.enqueue(o.id,'owner_paid',o.id||':owner-paid');return 'paid';
end $$;
create function public.mirai_payment_expired(p_order uuid,p_session text) returns void language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;
begin
 select * into o from public.mirai_orders where id=p_order for update;
 if o.provider_session is distinct from p_session then raise exception 'Session mismatch.';end if;
 if o.status not in ('confirmed','cancelled') or o.payment_reference is not null then return;end if;
 update mirai_private.stock_allocations set state='released' where order_id=o.id and state='held';
 update public.mirai_orders set status='cancelled',payment_url=null where id=o.id;
 perform mirai_private.enqueue(o.id,'expired',o.id||':expired');
end $$;
create function public.mirai_commerce_maintenance() returns integer language plpgsql security definer set search_path='' as $$
declare o record;n integer:=0;
begin
 for o in select * from public.mirai_orders where status='confirmed' and expires_at<now() for update skip locked loop
  if o.provider_session is null then
   update mirai_private.stock_allocations set state='released' where order_id=o.id and state='held';
   update public.mirai_orders set status='cancelled' where id=o.id;
   perform mirai_private.enqueue(o.id,'expired',o.id||':expired');
  else perform mirai_private.enqueue(o.id,'reconcile_payment',o.id||':reconcile');end if;n:=n+1;
 end loop;
 update public.mirai_commissions set status='payable' where status='pending' and payable_at<=now() and not exists(select 1 from public.mirai_orders o where o.id=mirai_commissions.order_id and o.payment_review);return n;
end $$;
create function public.mirai_refund_record(p_event text,p_order uuid,p_payment text,p_product_refunded integer) returns void language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;
begin
 select * into o from public.mirai_orders where id=p_order for update;
 if not found or o.payment_reference is distinct from p_payment or o.status not in ('paid','shipped','refunded') or p_product_refunded is null or p_product_refunded not between 0 and o.product_total_cents then raise exception 'Refund mismatch.';end if;
 if exists(select 1 from mirai_private.payment_events where event_id=p_event) then return;end if;
 insert into mirai_private.payment_events values(p_event,o.id,'refund',now());
 if p_product_refunded<o.product_refunded_cents then return;end if;
 update public.mirai_orders set product_refunded_cents=p_product_refunded,status=case when p_product_refunded=o.product_total_cents then 'refunded' else status end where id=o.id;
 update public.mirai_commissions set eligible_revenue_cents=o.product_total_cents-p_product_refunded,amount_cents=round((o.product_total_cents-p_product_refunded)*commission_bps::numeric/10000),status=case when p_product_refunded=o.product_total_cents then 'reversed' when status='paid' then 'pending' else status end where order_id=o.id;
 -- Refunds never silently restock physical goods. An owner must reconcile or inspect them.
 update public.mirai_orders set payment_review=true where id=o.id;
 perform mirai_private.enqueue(o.id,'owner_refund_review',p_event||':review');
end $$;
-- RLS and grants are explicit; inventory/customer email/job data never becomes public.
alter table mirai_private.commerce_settings enable row level security;
alter table mirai_private.stock_lots enable row level security;
alter table mirai_private.stock_allocations enable row level security;
alter table mirai_private.stock_movements enable row level security;
alter table mirai_private.commerce_jobs enable row level security;
alter table mirai_private.payment_events enable row level security;
revoke all on all tables in schema mirai_private from public,anon,authenticated;
revoke all on function mirai_private.enqueue(uuid,text,text) from public,anon,authenticated;
revoke all on function public.mirai_inventory(),public.mirai_stock_receive(text,text,text,integer,text,date,integer),public.mirai_stock_adjust(uuid,integer,text),public.mirai_request_v2(jsonb,text,text,uuid,jsonb),public.mirai_approve_order(uuid,integer,integer),public.mirai_cancel_order(uuid),public.mirai_ship_order(uuid,text,text) from public,anon;
grant execute on function public.mirai_inventory(),public.mirai_stock_receive(text,text,text,integer,text,date,integer),public.mirai_stock_adjust(uuid,integer,text),public.mirai_request_v2(jsonb,text,text,uuid,jsonb),public.mirai_approve_order(uuid,integer,integer),public.mirai_cancel_order(uuid),public.mirai_ship_order(uuid,text,text) to authenticated;
revoke all on function public.mirai_commerce_claim(),public.mirai_commerce_finish(uuid,uuid,text),public.mirai_payment_link(uuid,text,text),public.mirai_payment_received(text,uuid,text,text,integer,text),public.mirai_payment_expired(uuid,text),public.mirai_commerce_maintenance(),public.mirai_refund_record(text,uuid,text,integer) from public,anon,authenticated;
grant execute on function public.mirai_commerce_claim(),public.mirai_commerce_finish(uuid,uuid,text),public.mirai_payment_link(uuid,text,text),public.mirai_payment_received(text,uuid,text,text,integer,text),public.mirai_payment_expired(uuid,text),public.mirai_commerce_maintenance(),public.mirai_refund_record(text,uuid,text,integer) to service_role;

create function public.mirai_payment_exception(p_event text,p_order uuid,p_reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 perform 1 from public.mirai_orders where id=p_order for update;
 if not found then raise exception 'Order not found.';end if;
 if exists(select 1 from mirai_private.payment_events where event_id=p_event) then return;end if;
 insert into mirai_private.payment_events values(p_event,p_order,'review',now());
 update public.mirai_orders set payment_review=true where id=p_order;
 update public.mirai_commissions set status='pending',payable_at=null where order_id=p_order and status in ('pending','payable');
 insert into mirai_private.audit_events(action,record_id,details) values('payment_exception',p_order::text,jsonb_build_object('reason',left(p_reason,1000)));
 perform mirai_private.enqueue(p_order,'owner_payment_review',p_event||':review');
end $$;
revoke all on function public.mirai_payment_exception(text,uuid,text) from public,anon,authenticated;
grant execute on function public.mirai_payment_exception(text,uuid,text) to service_role;

-- Manual receipt recording: owner only, no payment service is contacted.
create function public.mirai_manual_payment(p_order uuid,p_method text,p_reference text,p_cents integer) returns text language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;ref text;result text;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 if (select provider from mirai_private.commerce_settings where id)<>'manual' then raise exception 'Manual payment mode is not enabled.';end if;
 if p_method is null or p_method not in ('zelle','cashapp','venmo','other') or length(trim(coalesce(p_reference,''))) not between 3 and 150 then raise exception 'Select a method and enter the actual transaction reference.';end if;
 select * into o from public.mirai_orders where id=p_order for update;
 if not found or o.status not in ('confirmed','paid','shipped') or o.provider_session is not null or o.payment_review then raise exception 'Approve inventory before recording payment.';end if;
 ref:='manual:'||p_method||':'||lower(trim(p_reference));
 result:=public.mirai_payment_received('receipt:'||o.id||':'||ref,o.id,null,ref,p_cents,'usd');
 if result='paid' then
  insert into mirai_private.audit_events(actor_id,action,record_id,details) values(auth.uid(),'manual_payment_verified',o.id::text,jsonb_build_object('method',p_method,'reference',trim(p_reference),'amount_cents',p_cents));
 end if;
 return result;
end $$;
revoke all on function public.mirai_manual_payment(uuid,text,text,integer) from public,anon;
grant execute on function public.mirai_manual_payment(uuid,text,text,integer) to authenticated;

commit;
