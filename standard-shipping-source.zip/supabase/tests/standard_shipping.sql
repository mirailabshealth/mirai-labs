begin;
select set_config('request.jwt.claim.sub','55a14f89-b637-4b77-bb59-e55e4e85326d',true);
do $$
declare q jsonb; oid uuid; a jsonb:='{"name":"Test Recipient","line1":"123 Test Street","line2":"URB Test","city":"San Juan","region":"PR","postal_code":"00901","country":"US"}'; items jsonb:='[{"compound_id":"retatrutide","vial_size":"20 mg/vial","quantity":1}]'; job uuid; tok uuid:=gen_random_uuid(); mail jsonb;
begin
 if mirai_private.standard_shipping(24999)<>1500 or mirai_private.standard_shipping(25000)<>0 or mirai_private.standard_shipping(25001)<>0 then raise exception 'Threshold failed';end if;
 if has_function_privilege('anon','public.mirai_shipping_quote(jsonb,text)','execute') then raise exception 'Anonymous quote exposed';end if;
 perform public.mirai_save_profile('Test Recipient','4075550100',a,true);
 q:=public.mirai_shipping_quote(items,'');
 if (q->>'shipping_cents')::int<>mirai_private.standard_shipping((q->>'total_cents')::int) or q->>'tax_cents' is not null then raise exception 'Quote mismatch or tax default';end if;
 oid:=public.mirai_request_v2(items,'','Rollback shipping test',gen_random_uuid(),a);
 if not exists(select 1 from public.mirai_orders where id=oid and shipping_cents=(q->>'shipping_cents')::int and shipping_address->>'region'='PR' and tax_cents is null and status='requested') then raise exception 'PR request snapshot failed';end if;
 begin
  perform public.mirai_approve_order(oid,1234,0);
  raise exception 'TEST FAIL shipping override accepted';
 exception when others then if sqlerrm not like 'Shipping must match%' then raise;end if;end;
 insert into mirai_private.stock_lots(compound_id,vial_size,batch,on_hand,low_stock) values('retatrutide','20 mg/vial','ROLLBACK-SHIPPING-'||oid,1,0);
 perform public.mirai_approve_order(oid,(q->>'shipping_cents')::int,123);
 if not exists(select 1 from public.mirai_orders where id=oid and status='confirmed' and shipping_cents=(q->>'shipping_cents')::int and tax_cents=123) then raise exception 'Approval amounts failed';end if;
 select id into job from mirai_private.commerce_jobs where order_id=oid and kind='manual_payment_instructions';
 update mirai_private.commerce_jobs set state='processing',lease_token=tok,lease_until=now()+interval '5 minutes' where id=job;
 mail:=public.mirai_payment_email_take(job,tok);
 if (mail->'order'->>'shipping_cents')::int is distinct from (q->>'shipping_cents')::int then raise exception 'Payment email shipping mismatch';end if;
 update public.mirai_catalog set single_cents=25000 where compound_id='retatrutide' and vial_size='20 mg/vial';
 q:=public.mirai_shipping_quote(items,'');
 if (q->>'shipping_cents')::int<>0 or (q->>'subtotal_with_shipping_cents')::int<>25000 then raise exception 'Exact threshold quote failed';end if;
 update public.mirai_catalog set single_cents=8700 where compound_id='retatrutide' and vial_size='20 mg/vial';
 q:=public.mirai_shipping_quote('[{"compound_id":"retatrutide","vial_size":"20 mg/vial","quantity":3}]','');
 if (q->>'total_cents')::int<>24795 or (q->>'shipping_cents')::int<>1500 then raise exception 'After-discount threshold failed';end if;
end $$;
rollback;
select 'PASS: $249.99/$250/$250.01 boundaries, after-discount subtotal, Puerto Rico address, pending tax, server shipping enforcement, stock approval and payment-email amount; all fixtures rolled back' as result;
