-- Standard shipping; product totals are after quantity and partner discounts.
begin;
create or replace function mirai_private.standard_shipping(p_total integer) returns integer language plpgsql immutable set search_path='' as $$
begin
 if p_total is null or p_total<0 then raise exception 'Valid product total required.';end if;
 return case when p_total>=25000 then 0 else 1500 end;
end $$;
revoke all on function mirai_private.standard_shipping(integer) from public,anon,authenticated;
create or replace function public.mirai_shipping_quote(p_items jsonb,p_code text default '') returns jsonb language plpgsql security definer set search_path='' as $$
declare q jsonb; ship integer;
begin
 q:=public.mirai_quote(p_items,p_code);
 ship:=mirai_private.standard_shipping((q->>'total_cents')::integer);
 return q||jsonb_build_object('shipping_cents',ship,'subtotal_with_shipping_cents',(q->>'total_cents')::integer+ship,'tax_cents',null,'shipping_policy','STANDARD-2026-10-03');
end $$;
revoke all on function public.mirai_shipping_quote(jsonb,text) from public,anon;
grant execute on function public.mirai_shipping_quote(jsonb,text) to authenticated;
create or replace function public.mirai_save_profile(p_name text,p_phone text,p_address jsonb,p_consent boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare k text; a jsonb:='{}';ph text:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
begin
 if not mirai_private.verified() then raise exception 'Verify your email and sign in first';end if;
 if p_consent is distinct from true then raise exception 'Research-use and policy acknowledgment required';end if;
 if length(btrim(coalesce(p_name,''))) not between 2 and 120 then raise exception 'Enter your full name';end if;
 if length(ph) not between 10 and 15 then raise exception 'Enter a valid phone number including area code';end if;
 if jsonb_typeof(p_address) is distinct from 'object' then raise exception 'Shipping address required';end if;
 foreach k in array array['name','line1','city','region','postal_code'] loop
  if length(btrim(coalesce(p_address->>k,''))) not between 1 and 200 then raise exception 'Complete all required shipping fields';end if;
  a:=a||jsonb_build_object(k,btrim(p_address->>k));
 end loop;
 if length(coalesce(p_address->>'organization',''))>200 then raise exception 'Organization is too long';end if;
 a:=a||jsonb_build_object('organization',btrim(coalesce(p_address->>'organization','')));
 if p_address->>'country'='PR' then p_address:=p_address||'{"country":"US","region":"PR"}'::jsonb;a:=a||'{"region":"PR"}'::jsonb;end if;
 if p_address->>'country' is distinct from 'US' then raise exception 'Only U.S. shipping is available';end if;
 if (a->>'postal_code') !~ '^[0-9]{5}(-[0-9]{4})?$' then raise exception 'Enter a five-digit ZIP code or ZIP+4';end if;
 if length(coalesce(p_address->>'line2',''))>200 then raise exception 'Address line is too long';end if;
 a:=a||jsonb_build_object('line2',btrim(coalesce(p_address->>'line2','')),'country','US');
 insert into public.mirai_profiles(user_id,display_name,phone,shipping_address,policy_accepted_at) values(auth.uid(),btrim(p_name),ph,a,now())
 on conflict(user_id) do update set display_name=excluded.display_name,phone=excluded.phone,shipping_address=excluded.shipping_address,policy_accepted_at=coalesce(mirai_profiles.policy_accepted_at,excluded.policy_accepted_at);
 return public.mirai_account(null);
end $$;
create or replace function public.mirai_request_v2(p_items jsonb,p_code text,p_notes text,p_request_key uuid,p_address jsonb) returns uuid language plpgsql security definer set search_path='' as $$
declare oid uuid;r text;
begin
 if not mirai_private.verified() then raise exception 'Verified account required.';end if;
 if jsonb_typeof(p_address) is distinct from 'object' or length(p_address::text)>3000 then raise exception 'Shipping address required.';end if;
 foreach r in array array['name','line1','city','region','postal_code','country'] loop
  if length(trim(coalesce(p_address->>r,''))) not between 1 and 200 then raise exception 'Complete all required shipping fields.';end if;
 end loop;
 if length(coalesce(p_address->>'organization',''))>200 then raise exception 'Organization is too long.';end if;
 if p_address->>'country'='PR' then p_address:=p_address||'{"country":"US","region":"PR"}'::jsonb;end if;
 if (p_address->>'postal_code') !~ '^[0-9]{5}(-[0-9]{4})?$' then raise exception 'Enter a valid ZIP code.';end if;
 if p_address->>'country'<>'US' then raise exception 'Only US shipping requests are supported at launch.';end if;
 -- Serialize retries of this user's request without trusting browser totals.
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(auth.uid()::text||p_request_key::text,0));
 select id into oid from public.mirai_orders where user_id=auth.uid() and request_key=p_request_key;
 if found then return oid;end if;
 oid:=public.mirai_request(p_items,p_code,p_notes,p_request_key);
 update public.mirai_orders set shipping_address=p_address,shipping_cents=mirai_private.standard_shipping(product_total_cents),commission_bps=(select a.commission_bps from public.mirai_affiliates a where a.user_id=mirai_orders.affiliate_id) where id=oid;
 perform mirai_private.enqueue(oid,'request_received',oid||':received');perform mirai_private.enqueue(oid,'owner_request',oid||':owner');return oid;
end $$;
create or replace function public.mirai_approve_order(p_order uuid,p_shipping integer,p_tax integer) returns void language plpgsql security definer set search_path='' as $$
declare o public.mirai_orders;s mirai_private.commerce_settings;r record;l record;needed integer;take_n integer;free_n integer;
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 select * into s from mirai_private.commerce_settings where id;
 if s.provider<>'manual' and (not s.payments_ready or not s.email_ready) then raise exception 'Payment and email connections must be tested and enabled before approval.';end if;
 if p_shipping is null or p_tax is null or p_shipping<0 or p_tax<0 then raise exception 'Confirm shipping and tax amounts.';end if;
 select * into o from public.mirai_orders where id=p_order for update;
 if not found then raise exception 'Order not found.';end if;
 if o.status='confirmed' then return;end if;
 if o.status<>'requested' or o.shipping_address is null then raise exception 'Order requires a new request with a shipping address.';end if;
 if p_shipping is distinct from mirai_private.standard_shipping(o.product_total_cents) then raise exception 'Shipping must match the standard rate: $15 below $250 after discounts, otherwise free.';end if;
 for r in select * from jsonb_to_recordset(o.items) as x(compound_id text,vial_size text,quantity integer) order by compound_id,vial_size loop
  perform 1 from public.mirai_catalog where compound_id=r.compound_id and vial_size=r.vial_size and active for update;
  if not found then raise exception 'A requested size is no longer active.';end if;
  needed:=r.quantity;
  for l in select * from mirai_private.stock_lots where compound_id=r.compound_id and vial_size=r.vial_size and (expires_on is null or expires_on>current_date) order by expires_on nulls last,created_at,id for update loop
   select l.on_hand-coalesce(sum(quantity),0) into free_n from mirai_private.stock_allocations where lot_id=l.id and state in ('held','committed');
   take_n:=least(needed,free_n);
   if take_n>0 then insert into mirai_private.stock_allocations(order_id,lot_id,quantity,state) values(o.id,l.id,take_n,'held');needed:=needed-take_n;end if;
   exit when needed=0;
  end loop;
  if needed>0 then raise exception 'Insufficient available stock for % (%). No inventory was reserved.',r.compound_id,r.vial_size;end if;
 end loop;
 update public.mirai_orders set status='confirmed',shipping_cents=p_shipping,tax_cents=p_tax,approved_at=now(),expires_at=case when s.provider='manual' then null else now()+make_interval(hours=>s.hold_hours) end where id=o.id;
 if s.provider<>'manual' then perform mirai_private.enqueue(o.id,'create_payment',o.id||':payment');end if;
 insert into mirai_private.audit_events(actor_id,action,record_id) values(auth.uid(),'order_approved',o.id::text);
end $$;
commit;
