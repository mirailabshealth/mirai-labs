-- Execute with migration in a rollback-only transaction.
do $$declare r record;begin
 for r in select * from (values (0::bigint,500),(249999,500),(250000,800),(999999,800),(1000000,1200),(2499999,1200),(2500000,1500),(4999999,1500),(5000000,2000),(9000000,2000)) t(sales,rate) loop
 assert mirai_private.commission_tier(r.sales)=r.rate,'Tier boundary failed';end loop;
end $$;
insert into auth.users(id,email,email_confirmed_at,raw_app_meta_data,raw_user_meta_data,aud,role) values
('00000000-0000-4000-8000-000000000701','tier-customer@example.invalid',now(),'{}','{}','authenticated','authenticated'),
('00000000-0000-4000-8000-000000000702','tier-affiliate@example.invalid',now(),'{}','{}','authenticated','authenticated');
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000701',true);
select public.mirai_save_profile('Tier Test','4075550100','{"name":"Tier Test","line1":"123 Test Street","city":"Test","region":"FL","postal_code":"34741","country":"US"}',true);
insert into public.mirai_affiliates(user_id,code,active,commission_bps) values('00000000-0000-4000-8000-000000000702','TIERSFIXTURE',true,2000);
do $$declare oid uuid;begin
 assert (select commission_bps from public.mirai_affiliates where code='TIERSFIXTURE')=500,'Manual rate override';
 insert into public.mirai_orders(user_id,request_key,items,product_total_cents,affiliate_id,referral_code,status,shipping_cents,tax_cents,commission_bps)
 values('00000000-0000-4000-8000-000000000701',gen_random_uuid(),'[]',250000,'00000000-0000-4000-8000-000000000702','TIERSFIXTURE','confirmed',0,0,500) returning id into oid;
 assert mirai_private.qualifying_sales('00000000-0000-4000-8000-000000000702')=0,'Unpaid sale counted';
 assert public.mirai_payment_received('tier-fixture-pay',oid,null,'tier-fixture-payment',250000,'usd')='paid','Paid transition failed';
 assert (select commission_bps from public.mirai_affiliates where code='TIERSFIXTURE')=800,'Payment did not advance tier';
 assert (select amount_cents from public.mirai_commissions where order_id=oid)=12500,'Threshold order must retain snapshot';
 assert public.mirai_payment_received('tier-fixture-pay-again',oid,null,'tier-fixture-payment',250000,'usd')='duplicate','Duplicate payment';
 assert mirai_private.qualifying_sales('00000000-0000-4000-8000-000000000702')=250000,'Duplicate sales';
 update public.mirai_orders set payment_review=true where id=oid;
 assert (select commission_bps from public.mirai_affiliates where code='TIERSFIXTURE')=500,'Dispute not excluded';
 update public.mirai_orders set payment_review=false where id=oid;
 assert (select commission_bps from public.mirai_affiliates where code='TIERSFIXTURE')=800,'Cleared hold not restored';
 perform public.mirai_refund_record('tier-refund',oid,'tier-fixture-payment',100);
 assert mirai_private.qualifying_sales('00000000-0000-4000-8000-000000000702')=0,'Refund review not excluded';
 update public.mirai_orders set payment_review=false where id=oid;
 assert mirai_private.qualifying_sales('00000000-0000-4000-8000-000000000702')=249900,'Partial refund counted incorrectly';
 assert (select commission_bps from public.mirai_affiliates where code='TIERSFIXTURE')=500,'Refund tier not corrected';
 assert (select commission_bps from public.mirai_commissions where order_id=oid)=500,'Historic rate changed';
end $$;
select set_config('request.jwt.claim.sub','00000000-0000-4000-8000-000000000702',true);
select public.mirai_save_profile('Affiliate Test','4075550101','{"name":"Affiliate Test","line1":"123 Test Street","city":"Test","region":"FL","postal_code":"34741","country":"US"}',true);
set local role authenticated;
do $$begin
 assert (public.mirai_affiliate_progress()->>'qualifying_sales_cents')::bigint=249900,'Progress RPC failed';
 begin perform public.mirai_owner_affiliate_tiers();raise exception 'Affiliate accessed owner tiers';exception when raise_exception then if sqlerrm<>'Owner access required.' then raise;end if;end;
end $$;
reset role;
set local role anon;
do $$begin begin perform public.mirai_affiliate_progress();raise exception 'Anonymous access accepted';exception when insufficient_privilege then null;end;end $$;
reset role;
do $$declare oid uuid; r record; paid integer;begin
 -- The database rejects self-attributed purchases.
 begin
 insert into public.mirai_orders(user_id,request_key,items,product_total_cents,affiliate_id,status,shipping_cents,tax_cents,commission_bps,paid_at)
 values('00000000-0000-4000-8000-000000000702',gen_random_uuid(),'[]',5000000,'00000000-0000-4000-8000-000000000702','paid',0,0,500,now()) returning id into oid;
 raise exception 'Self attribution accepted';
 exception when check_violation then null;end;
 assert mirai_private.qualifying_sales('00000000-0000-4000-8000-000000000702')=249900,'Self purchase counted';
 for r in select * from (values (100,250000,800),(750000,1000000,1200),(1500000,2500000,1500),(2500000,5000000,2000)) t(additional,total,rate) loop
  insert into public.mirai_orders(user_id,request_key,items,product_total_cents,affiliate_id,status,shipping_cents,tax_cents,commission_bps)
  values('00000000-0000-4000-8000-000000000701',gen_random_uuid(),'[]',r.additional,'00000000-0000-4000-8000-000000000702','confirmed',1500,200,500) returning id into oid;
  perform public.mirai_payment_received('tier-'||oid,oid,null,'tier-pay-'||oid,r.additional+1700,'usd');
  assert mirai_private.qualifying_sales('00000000-0000-4000-8000-000000000702')=r.total,'Shipping or tax counted';
  assert (select commission_bps from public.mirai_affiliates where code='TIERSFIXTURE')=r.rate,'Payment tier boundary failed';
 end loop;
end $$;
select 'PASS: all tier boundaries, paid-only sales, automatic promotion, rate snapshot, duplicate payment, dispute hold, partial refund correction and authenticated progress; fixtures rolled back.' as result;
