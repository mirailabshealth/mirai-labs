begin;
create or replace function mirai_private.commission_tier(p_sales bigint) returns integer language sql immutable set search_path='' as $$
 select case when p_sales>=5000000 then 2000 when p_sales>=2500000 then 1500 when p_sales>=1000000 then 1200 when p_sales>=250000 then 800 else 500 end;
$$;
create or replace function mirai_private.qualifying_sales(p_affiliate uuid) returns bigint language sql volatile security definer set search_path='' as $$
 select coalesce(sum(o.product_total_cents-o.product_refunded_cents),0)::bigint from public.mirai_orders o
 where o.affiliate_id=p_affiliate and o.user_id<>p_affiliate and o.status in ('paid','shipped') and o.paid_at is not null and not o.payment_review
 and exists(select 1 from public.mirai_commissions c where c.order_id=o.id and c.status<>'reversed');
$$;
create or replace function mirai_private.enforce_commission_tier() returns trigger language plpgsql security definer set search_path='' as $$
-- The UPDATE locks the affiliate row before this trigger calculates its rate.
-- VOLATILE qualifying_sales takes a fresh snapshot after concurrent writers finish.
begin new.commission_bps:=mirai_private.commission_tier(mirai_private.qualifying_sales(new.user_id));return new;end $$;
drop trigger if exists mirai_affiliate_auto_tier on public.mirai_affiliates;
create trigger mirai_affiliate_auto_tier before insert or update on public.mirai_affiliates for each row execute function mirai_private.enforce_commission_tier();
create or replace function mirai_private.refresh_commission_tier() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.affiliate_id is not null then update public.mirai_affiliates set commission_bps=commission_bps where user_id=new.affiliate_id;end if;
 if TG_OP='UPDATE' and old.affiliate_id is distinct from new.affiliate_id and old.affiliate_id is not null then update public.mirai_affiliates set commission_bps=commission_bps where user_id=old.affiliate_id;end if;
 return new;
end $$;
drop trigger if exists mirai_ledger_tier_refresh on public.mirai_commissions;
create trigger mirai_ledger_tier_refresh after insert or update on public.mirai_commissions for each row execute function mirai_private.refresh_commission_tier();
drop trigger if exists mirai_order_tier_refresh on public.mirai_orders;
create trigger mirai_order_tier_refresh after update of status,payment_review,product_refunded_cents,paid_at,affiliate_id,product_total_cents on public.mirai_orders for each row execute function mirai_private.refresh_commission_tier();
create or replace function public.mirai_affiliate_progress() returns jsonb language plpgsql security definer set search_path='' as $$
declare sales bigint; rate integer; target bigint;begin
 if not mirai_private.verified() then raise exception 'Please verify your email and sign in.';end if;
 if not exists(select 1 from public.mirai_affiliates where user_id=auth.uid() and active) then raise exception 'Active affiliate access required.';end if;
 sales:=mirai_private.qualifying_sales(auth.uid());rate:=mirai_private.commission_tier(sales);
 target:=case when sales<250000 then 250000 when sales<1000000 then 1000000 when sales<2500000 then 2500000 when sales<5000000 then 5000000 else null end;
 return jsonb_build_object('qualifying_sales_cents',sales,'commission_bps',rate,'next_threshold_cents',target,'remaining_cents',greatest(target-sales,0));
end $$;
revoke all on function mirai_private.commission_tier(bigint),mirai_private.qualifying_sales(uuid),mirai_private.enforce_commission_tier(),mirai_private.refresh_commission_tier() from public,anon,authenticated;
revoke all on function public.mirai_affiliate_progress() from public,anon;
grant execute on function public.mirai_affiliate_progress() to authenticated;
create or replace function public.mirai_review_affiliate(p_user_id uuid,p_approve boolean,p_code text,p_commission_bps integer default 500) returns void language plpgsql security definer set search_path='' as $$
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.'; end if;
 perform 1 from public.mirai_affiliate_applications where user_id=p_user_id for update;
 if not found then raise exception 'Application not found.'; end if;
 if p_approve then
  insert into public.mirai_affiliates(user_id,code,active,commission_bps) values(p_user_id,upper(trim(p_code)),true,500) on conflict(user_id) do update set code=excluded.code,active=true,commission_bps=excluded.commission_bps;
 else update public.mirai_affiliates set active=false where user_id=p_user_id;
 end if;
 update public.mirai_affiliate_applications set status=case when p_approve then 'approved' else 'rejected' end,reviewed_at=now() where user_id=p_user_id;
 insert into mirai_private.audit_events(actor_id,action,record_id,details) values(auth.uid(),'affiliate_review',p_user_id::text,jsonb_build_object('approved',p_approve,'commission_bps',(select commission_bps from public.mirai_affiliates where user_id=p_user_id),'tier_mode','automatic'));
end $$;


create or replace function public.mirai_owner_affiliate_tiers() returns jsonb
language plpgsql security definer set search_path='' as $$
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 return coalesce((select jsonb_agg(jsonb_build_object('code',a.code,'active',a.active,
 'commission_bps',mirai_private.commission_tier(mirai_private.qualifying_sales(a.user_id)),
 'qualifying_sales_cents',mirai_private.qualifying_sales(a.user_id)) order by a.code)
 from public.mirai_affiliates a),'[]'::jsonb);
end $$;
revoke all on function public.mirai_owner_affiliate_tiers() from public,anon;
grant execute on function public.mirai_owner_affiliate_tiers() to authenticated;

-- No historical commissions or order snapshots are changed.
update public.mirai_affiliates set commission_bps=commission_bps;
commit;
