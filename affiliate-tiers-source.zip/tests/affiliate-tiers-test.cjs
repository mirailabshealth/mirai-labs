const fs=require('fs'),assert=require('assert'),vm=require('vm'),{JSDOM}=require('jsdom');
const source=fs.readFileSync('/workspace/scratch/a72500340f12/deploy/mirai-labs/portal.html','utf8');
for(const match of source.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)) if(match[1].trim()) new vm.Script(match[1]);
const w=new JSDOM('<section id="affiliate-progress"></section><section id="owner-affiliate-tiers"></section>',{runScripts:'outside-only'}).window;
Object.assign(w,{$:id=>w.document.getElementById(id),money:c=>'$'+(c/100).toFixed(2),esc:s=>String(s).replaceAll('<','&lt;').replaceAll('>','&gt;')});
w.eval(source.slice(source.indexOf('const affiliateMilestones='),source.indexOf('async function renderAffiliate()')));
(async()=>{
 for(const [sales,rate,target] of [[0,500,250000],[249999,500,250000],[250000,800,1000000],[1000000,1200,2500000],[2500000,1500,5000000],[5000000,2000,null]]){
 w.rpc=async()=>({qualifying_sales_cents:sales,commission_bps:rate,next_threshold_cents:target,remaining_cents:Math.max(0,target-sales)});
 await w.loadAffiliateProgress();const body=w.document.querySelector('#affiliate-progress').textContent;assert(body.includes(rate/100+'% current commission'));assert(body.includes(target===null?'highest commission tier':'to reach'));assert.equal(w.document.querySelectorAll('#affiliate-progress .item').length,5);
 }
 w.rpc=async()=>[{code:'<script>bad</script>',active:true,commission_bps:800,qualifying_sales_cents:250000}];await w.loadOwnerAffiliateTiers();assert.equal(w.document.querySelectorAll('script').length,0);assert(w.document.querySelector('#owner-affiliate-tiers').textContent.includes('$7500.00 to 12%'));
 w.rpc=async()=>{throw Error('offline')};await w.loadAffiliateProgress();await w.loadOwnerAffiliateTiers();assert(w.document.body.textContent.includes('Order and application controls remain available'));
 assert(!source.includes('f.elements.commission'));assert(source.includes('loadOwnerAnalytics();loadOwnerAffiliateTiers();'));
 console.log('PASS: JS syntax; 6 tier progress states; max tier; owner progress; escaped codes; failure isolation; automatic-only approval UI');
})().catch(e=>{console.error(e);process.exit(1)});
