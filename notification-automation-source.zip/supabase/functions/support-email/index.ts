// Private delivery capability: each request requires a one-use DB-minted job token.
// No caller can choose a recipient, amount, payment handle or email content.
import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import nodemailer from 'npm:nodemailer@^9';
const OWNER = 'mirai.labs.health@gmail.com';
export function customerOrderMessage(job: any) {
  const portal='https://mirailabshealth.github.io/mirai-labs/portal.html';
  if (!/^MIR-[0-9]+$/.test(job.order_number || '')) throw Error('Invalid order number');
  if(job.kind==='request_received') return {
    subject:`Mirai Labs: request ${job.order_number} received`,
    text:`Thank you for your request.\n\nOrder number: ${job.order_number}\n\nYour request is awaiting inventory and owner approval. This email is not an approval or payment confirmation. Please do not send payment yet.\n\nAfter approval, we will email the final total and payment instructions. Include your order number as the payment reference and send payment only once.\n\nView your request and its status in your client portal:\n${portal}\n\nQuestions? Reply to this email.\n\nMirai Labs\n${OWNER}\nFor laboratory research use only. Not for human or animal consumption.`
  };
  if(job.kind!=='shipped' || !job.tracking_number || /[\r\n]/.test(job.tracking_number)) throw Error('Invalid shipment');
  const tracking=new URL(job.tracking_url);if(tracking.protocol!=='https:' || tracking.username || tracking.password)throw Error('Invalid tracking URL');
  return {subject:`Mirai Labs: order ${job.order_number} shipping update`,text:`Your order has been marked shipped by Mirai Labs.\n\nOrder number: ${job.order_number}\nTracking number: ${job.tracking_number}\nTrack your shipment: ${tracking.href}\n\nTracking may take time to appear after the carrier scans the package. You can also view tracking in your client portal:\n${portal}\n\nIf anything arrives damaged or incorrect, keep the packaging and photos and contact us promptly with your order number.\n\nQuestions? Reply to this email.\n\nMirai Labs\n${OWNER}\nFor laboratory research use only. Not for human or animal consumption.`};
}
export function notificationMessage(job: any) {
  const portal='https://mirailabshealth.github.io/mirai-labs/portal.html';
  const footer=`\n\nMirai Labs\nQuestions? Reply to this email.\nFor laboratory research use only. Not for human or animal consumption.`;
  let subject: string, text: string;
  switch(job.kind) {
    case 'affiliate_received':
      subject='Mirai Labs: affiliate application received';
      text='We received your affiliate application. An owner will review it and email you a decision. Your application is not approved yet. Please do not submit it again. No payment is required to apply.';break;
    case 'owner_affiliate':
      subject='Mirai Labs: affiliate application needs review';
      text=`A new affiliate application is awaiting your review. Sign in to the owner portal and open Affiliates.\n\n${portal}?view=admin\n\nReview the profile and audience details before approving or declining. Your decision queues an email to the applicant. This alert does not approve the application.`;break;
    case 'affiliate_approved':
      subject='Mirai Labs: your affiliate application is approved';
      text=job.source==='public' ? `Your affiliate application has been approved. Complete these steps to activate your partnership:\n\n1. Create an account, or sign in, using the same email address where you received this message.\n2. Verify that email and complete your account details.\n3. Open the Affiliate portal and choose your permanent affiliate code. You can choose it only once; it cannot be changed.\n\n${portal}?view=affiliate\n\nYour code becomes usable after activation. Commission applies to eligible paid product revenue under the partner terms; approval alone does not create earnings.` : `Your affiliate application has been approved. Sign in to the Affiliate portal to view your permanent code, referrals and commission status.\n\n${portal}?view=affiliate\n\nCommission applies to eligible paid product revenue under the partner terms; approval alone does not create earnings.`;break;
    case 'affiliate_rejected':
      subject='Mirai Labs: affiliate application update';
      text='Thank you for your interest in Mirai Labs. We are not approving your affiliate application at this time. If you have questions about this decision, reply to this email.';break;
    case 'owner_payment':
    case 'owner_order':
      if (!/^MIR-[0-9]+$/.test(job.order_number || '')) throw Error('Invalid order number');
      subject=`Mirai Labs: ${job.order_number} ${job.kind==='owner_payment'?'payment needs verification':'needs approval'}`;
      text=job.kind==='owner_payment' ? `A customer submitted payment details for order ${job.order_number}. This is a customer report, not proof of payment. Check the actual deposit in your payment account before marking paid.\n\n${portal}?view=admin` : `Order ${job.order_number} is awaiting your review. Check inventory and shipping details before approving. Approval triggers payment instructions; it does not confirm payment.\n\n${portal}?view=admin`;break;
    case 'notification_test':
      subject='Mirai Labs: notification delivery test';
      text='This is a notification delivery test. No customer application or order was created, approved or paid.';break;
    default: throw Error('Invalid notification');
  }
  return {subject,text:text+footer};
}
const reply = (status: number, body: string) => new Response(body, {status});
Deno.serve(async (req) => {
  if (req.method !== 'POST') return reply(405, 'Method not allowed');
  let body;
  try { const text = await req.text(); if (text.length > 1024) return reply(413, 'Request too large'); body = JSON.parse(text); }
  catch { return reply(400, 'Invalid request'); }
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuid.test(body?.job_id ?? '') || !uuid.test(body?.token ?? '')) return reply(401, 'Unauthorized');
  if (body.kind !== undefined && body.kind !== 'owner_request' && body.kind !== 'customer_order' && body.kind !== 'notification') return reply(400, 'Invalid notification kind');
  const ownerAlert = body.kind === 'owner_request';
  const customerOrder = body.kind === 'customer_order';
  const notification = body.kind === 'notification';
  const prefix = notification ? 'mirai_notification_email_' : ownerAlert ? 'mirai_owner_email_' : customerOrder ? 'mirai_customer_email_' : 'mirai_support_email_';
  const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {auth:{persistSession:false,autoRefreshToken:false}});
  const {data: job, error} = await db.rpc(prefix+'take', {p_job:body.job_id,p_token:body.token});
  if (error) return reply(503, 'Delivery unavailable');
  if (!job) return reply(401, 'Invalid or consumed delivery token');
  if (job.skipped) return reply(200, 'Skipped stale notification');
  let transport: any;
  let sending = false;
  try {
    const password = Deno.env.get('MIRAI_SMTP_PASSWORD');
    if (!password) throw Error('CONFIG');
    if(typeof job.email!=='string' || !/^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(job.email)) throw Error('Invalid recipient');
    const message = notification ? notificationMessage(job) : customerOrder ? customerOrderMessage(job) : ownerAlert ? {subject:job.test ? 'Mirai Labs: owner order alerts are connected' : `Mirai Labs: order ${job.order_number} needs approval`, text:job.test ? `Owner order notifications are connected. New requests will email this address with an order number and a link to the owner portal.

This is a notification test only. No order was created, approved or paid.

https://mirailabshealth.github.io/mirai-labs/portal.html?view=admin` : `A new order request is awaiting your review.

Order: ${job.order_number}

Sign in to the owner portal and find this order under Order requests & fulfillment:
https://mirailabshealth.github.io/mirai-labs/portal.html?view=admin

Review the items, shipping details and available inventory before approving. Approval will trigger the existing payment-instructions email. This notification does not approve the order or confirm payment.

Mirai Labs`} : {subject:`Mirai Labs: reply to ${job.ticket_number}`, text:`Hello,\n\nMirai Labs has replied to support ticket ${job.ticket_number}. Sign in to read the reply and continue the conversation:\nhttps://mirailabshealth.github.io/mirai-labs/portal.html?view=support\n\nUse the Support tab and select ${job.ticket_number}. For your privacy, message details are only displayed in your account.\n\nThis support update does not approve an order or verify payment.\n\nMirai Labs\n${OWNER}`};
    transport = nodemailer.createTransport({host:'smtp.gmail.com',port:465,secure:true,auth:{user:OWNER,pass:password},connectionTimeout:15000,greetingTimeout:15000,socketTimeout:20000});
    await transport.verify();
    // Consume the delivery lease immediately before SMTP sending.
    const {data: valid, error: startError} = await db.rpc(prefix+'start', {p_job:body.job_id,p_token:body.token});
    if (startError) throw Error('START');
    if (!valid) return reply(200, 'Delivery no longer active');
    sending = true;
    const result = await transport.sendMail({from:`Mirai Labs <${OWNER}>`,to:job.email,replyTo:OWNER,subject:message.subject,text:message.text,messageId:`<mirai-${notification?'notification':ownerAlert?'owner-order':customerOrder?'customer-order':'support'}-${body.job_id}@gmail.com>`});
    if (!result.accepted?.length) throw Error('SEND');
    const {error: finishError} = await db.rpc(prefix+'finish', {p_job:body.job_id,p_token:body.token,p_sent:true,p_error:null});
    if (finishError) return reply(503, 'Delivery needs owner review');
    return reply(200, 'Email accepted by SMTP server');
  } catch {
    // A timeout after SMTP begins is ambiguous; never automatically resend it.
    const safeError = sending ? 'Delivery outcome uncertain. Check Gmail Sent before retrying.' : 'Email configuration or connection failed before sending.';
    await db.rpc(prefix+'finish', {p_job:body.job_id,p_token:body.token,p_sent:false,p_error:safeError});
    return reply(503, 'Email delivery needs attention');
  } finally { transport?.close(); }
});
