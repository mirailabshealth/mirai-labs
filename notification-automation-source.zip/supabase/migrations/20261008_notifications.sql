-- Transactional notifications; no changes to approvals, payments or commissions.
begin;
create table mirai_private.notification_jobs (
 id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(),
 kind text not null check(kind in ('affiliate_received','owner_affiliate','affiliate_approved','affiliate_rejected','owner_payment','owner_order','notification_test')),
 source text not null check(source in ('public','account','order','test')), record_id uuid not null,
 recipient text not null, state text not null default 'pending' check(state in ('pending','processing','prepared','sending','sent','failed','skipped')),
 attempts int not null default 0, lease_token uuid, lease_until timestamptz, sent_at timestamptz, last_error text,
 unique(kind,source,record_id,recipient)
);
alter table mirai_private.notification_jobs enable row level security;
revoke all on mirai_private.notification_jobs from public,anon,authenticated;
create function mirai_private.queue_affiliate_notifications() returns trigger language plpgsql security definer set search_path='' as $$
declare src text; rid uuid; email_address text; k text;
begin
 src:=case when tg_table_name='mirai_public_affiliate_applications' then 'public' else 'account' end;
 if src='public' then rid:=new.id;email_address:=new.email;
 else rid:=new.user_id;select email into email_address from auth.users where id=new.user_id and email_confirmed_at is not null and deleted_at is null;end if;
 if tg_op='INSERT' and new.status='pending' then
  if email_address is not null then insert into mirai_private.notification_jobs(kind,source,record_id,recipient) values('affiliate_received',src,rid,email_address) on conflict do nothing;end if;
  insert into mirai_private.notification_jobs(kind,source,record_id,recipient)
   select 'owner_affiliate',src,rid,lower(u.email) from mirai_private.administrators a join auth.users u on u.id=a.user_id where u.email_confirmed_at is not null and u.deleted_at is null on conflict do nothing;
 elsif tg_op='UPDATE' then
  if old.status is distinct from new.status and new.status in ('approved','rejected') and email_address is not null then
   k:='affiliate_'||new.status;
   insert into mirai_private.notification_jobs(kind,source,record_id,recipient) values(k,src,rid,email_address) on conflict do nothing;
  end if;
 end if;
 return new;
end $$;
create trigger notify_public_affiliate after insert or update of status on public.mirai_public_affiliate_applications for each row execute function mirai_private.queue_affiliate_notifications();
create trigger notify_account_affiliate after insert or update of status on public.mirai_affiliate_applications for each row execute function mirai_private.queue_affiliate_notifications();
create function mirai_private.queue_order_notifications() returns trigger language plpgsql security definer set search_path='' as $$
declare rid uuid; k text;
begin
 if tg_table_name='mirai_payment_submissions' then rid:=new.order_id;k:='owner_payment';else rid:=new.id;k:='owner_order';end if;
 -- Existing order-request worker already alerts the primary owner.
 insert into mirai_private.notification_jobs(kind,source,record_id,recipient)
 select k,'order',rid,lower(u.email) from mirai_private.administrators a join auth.users u on u.id=a.user_id where u.email_confirmed_at is not null and u.deleted_at is null and (k<>'owner_order' or lower(u.email)<>'mirai.labs.health@gmail.com') on conflict do nothing;
 return new;
end $$;
create trigger notify_payment_submission after insert on public.mirai_payment_submissions for each row execute function mirai_private.queue_order_notifications();
create trigger notify_order_coowners after insert on public.mirai_orders for each row when (new.status='requested') execute function mirai_private.queue_order_notifications();
create function mirai_private.notification_eligible(j mirai_private.notification_jobs) returns boolean language plpgsql stable security definer set search_path='' as $$
declare s text;
begin
 if j.kind like 'owner_%' or j.kind='notification_test' then
  if not exists(select 1 from mirai_private.administrators a join auth.users u on u.id=a.user_id where lower(u.email)=lower(j.recipient) and u.email_confirmed_at is not null and u.deleted_at is null) then return false;end if;
 end if;
 if j.source='public' then select status into s from public.mirai_public_affiliate_applications where id=j.record_id;
 elsif j.source='account' then select status into s from public.mirai_affiliate_applications where user_id=j.record_id;
 elsif j.source='order' then
  return exists(select 1 from public.mirai_orders where id=j.record_id and ((j.kind='owner_order' and status='requested') or (j.kind='owner_payment' and status='confirmed')));
 elsif j.source='test' then return j.kind='notification_test';end if;
 return case j.kind when 'affiliate_received' then s='pending' when 'owner_affiliate' then s='pending' when 'affiliate_approved' then s='approved' when 'affiliate_rejected' then s='rejected' else false end;
end $$;
create function public.mirai_notification_email_take(p_job uuid,p_token uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare j mirai_private.notification_jobs; num text;
begin
 select * into j from mirai_private.notification_jobs where id=p_job and lease_token=p_token and state='processing' and lease_until>now() for update;
 if not found then return null;end if;
 if not mirai_private.notification_eligible(j) then
  update mirai_private.notification_jobs set state='skipped',lease_token=null,lease_until=null,last_error='Notification no longer applicable.' where id=j.id;
  return jsonb_build_object('skipped',true);
 end if;
 if j.source='order' then select order_number into num from public.mirai_orders where id=j.record_id;end if;
 update mirai_private.notification_jobs set state='prepared' where id=j.id;
 return jsonb_build_object('email',j.recipient,'kind',j.kind,'source',j.source,'order_number',num);
end $$;
create function public.mirai_notification_email_start(p_job uuid,p_token uuid) returns boolean language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.notification_jobs j set state='sending',lease_until=now()+interval '5 minutes' where id=p_job and lease_token=p_token and state='prepared' and lease_until>now() and mirai_private.notification_eligible(j) and (select email_ready from mirai_private.commerce_settings where id);
 return found;
end $$;
create function public.mirai_notification_email_finish(p_job uuid,p_token uuid,p_sent boolean,p_error text) returns void language plpgsql security definer set search_path='' as $$
begin
 update mirai_private.notification_jobs set state=case when p_sent then 'sent' else 'failed' end,sent_at=case when p_sent then now() else null end,last_error=case when p_sent then null else left(p_error,200) end,lease_token=null,lease_until=null where id=p_job and lease_token=p_token and ((p_sent and state='sending') or (not p_sent and state in ('prepared','sending')));
 if not found then raise exception 'Delivery lease invalid.';end if;
end $$;
create function mirai_private.dispatch_notifications() returns void language plpgsql security definer set search_path='' as $$
declare j record; token uuid;
begin
 update mirai_private.notification_jobs set state='failed',last_error='Delivery outcome uncertain. Check Gmail Sent before retrying.',lease_token=null,lease_until=null where state='sending' and lease_until<now();
 update mirai_private.notification_jobs set state='failed',last_error='Could not start after three attempts.',lease_token=null,lease_until=null where state in ('processing','prepared') and lease_until<now() and attempts>=3;
 if not coalesce((select email_ready from mirai_private.commerce_settings where id),false) then return;end if;
 for j in select id from mirai_private.notification_jobs where attempts<3 and (state='pending' or (state in ('processing','prepared') and lease_until<now())) order by created_at for update skip locked limit 10 loop
  token:=gen_random_uuid();
  update mirai_private.notification_jobs set state='processing',attempts=attempts+1,lease_token=token,lease_until=now()+interval '5 minutes' where id=j.id;
  perform net.http_post(url:='https://qymwaujpaxbmeohcmueh.supabase.co/functions/v1/support-email',headers:='{"Content-Type":"application/json"}'::jsonb,body:=jsonb_build_object('job_id',j.id,'token',token,'kind','notification'),timeout_milliseconds:=60000);
 end loop;
end $$;
create function public.mirai_notification_activity() returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if not mirai_private.is_admin() then raise exception 'Owner access required.';end if;
 return coalesce((select jsonb_agg(to_jsonb(r)) from (select id,created_at,kind,source,record_id,recipient,state,attempts,sent_at,last_error from mirai_private.notification_jobs order by created_at desc limit 100) r),'[]'::jsonb);
end $$;
revoke all on function mirai_private.queue_affiliate_notifications(),mirai_private.queue_order_notifications(),mirai_private.notification_eligible(mirai_private.notification_jobs),mirai_private.dispatch_notifications(),public.mirai_notification_email_take(uuid,uuid),public.mirai_notification_email_start(uuid,uuid),public.mirai_notification_email_finish(uuid,uuid,boolean,text),public.mirai_notification_activity() from public,anon,authenticated;
grant execute on function public.mirai_notification_email_take(uuid,uuid),public.mirai_notification_email_start(uuid,uuid),public.mirai_notification_email_finish(uuid,uuid,boolean,text) to service_role;
grant execute on function public.mirai_notification_activity() to authenticated;
-- No historical application or order emails are backfilled.
-- Schedule only after deploying the compatible email worker.
commit;
