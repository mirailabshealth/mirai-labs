-- Deploy compatible support-email worker first.
select cron.schedule('mirai-affiliate-owner-notifications','* * * * *','select mirai_private.dispatch_notifications();');
