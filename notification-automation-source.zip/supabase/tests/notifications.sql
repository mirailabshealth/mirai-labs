-- Run after migration inside BEGIN ... ROLLBACK. Never dispatch test jobs.
do $$
declare aid uuid:=gen_random_uuid(); req uuid:=gen_random_uuid(); jid uuid; tok uuid:=gen_random_uuid(); result jsonb; n int;
begin
 if has_table_privilege('anon','mirai_private.notification_jobs','select') then raise exception 'Private queue exposed';end if;
 if has_function_privilege('anon','public.mirai_notification_email_take(uuid,uuid)','execute') then raise exception 'Private delivery exposed';end if;
 insert into public.mirai_public_affiliate_applications(id,full_name,email,platform,profile,statement,request_key) values(aid,'Notification test','test@example.invalid','instagram','@test','Transactional test only',req);
 select count(*) into n from mirai_private.notification_jobs where source='public' and record_id=aid;
 if n<>1+(select count(*) from mirai_private.administrators a join auth.users u on u.id=a.user_id where u.email_confirmed_at is not null and u.deleted_at is null) then raise exception 'Applicant and owner notifications missing';end if;
 update public.mirai_public_affiliate_applications set status='approved' where id=aid;
 update public.mirai_public_affiliate_applications set status='approved' where id=aid;
 if (select count(*) from mirai_private.notification_jobs where record_id=aid and kind='affiliate_approved')<>1 then raise exception 'Duplicate decision email';end if;
 select id into jid from mirai_private.notification_jobs where record_id=aid and kind='affiliate_approved';
 if public.mirai_notification_email_take(jid,gen_random_uuid()) is not null then raise exception 'Forged token accepted';end if;
 update mirai_private.notification_jobs set state='processing',lease_token=tok,lease_until=now()+interval '5 minutes' where id=jid;
 result:=public.mirai_notification_email_take(jid,tok);
 if result->>'kind'<>'affiliate_approved' or result->>'email'<>'test@example.invalid' then raise exception 'Wrong delivery payload';end if;
 if public.mirai_notification_email_take(jid,tok) is not null then raise exception 'Replayed take accepted';end if;
 if not public.mirai_notification_email_start(jid,tok) then raise exception 'Valid start failed';end if;
 if public.mirai_notification_email_start(jid,tok) then raise exception 'Replayed start accepted';end if;
 perform public.mirai_notification_email_finish(jid,tok,true,null);
 if (select state from mirai_private.notification_jobs where id=jid)<>'sent' then raise exception 'Finish failed';end if;
 select id into jid from mirai_private.notification_jobs where record_id=aid and kind='affiliate_received';
 update mirai_private.notification_jobs set state='processing',lease_token=tok,lease_until=now()+interval '5 minutes' where id=jid;
 if (public.mirai_notification_email_take(jid,tok)->>'skipped') is distinct from 'true' then raise exception 'Stale message not skipped';end if;
end $$;
select 'PASS: private queue, applicant and owner jobs, decision deduplication, forged/replayed token rejection, stale-message skipping. Test data rolled back.' as result;
