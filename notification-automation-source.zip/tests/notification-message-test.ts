export function customerOrderMessage(job: any) {
  const portal='https://mirailabshealth.github.io/mirai-labs/portal.html';
  if (!/^MIR-[0-9]+$/.test(job.order_number || '')) throw Error('Invalid order number');
  if(job.kind==='request_received') return {
    subject:`Mirai Labs: request ${job.order_number} received`,
    text:`Thank you for your request.\n\nOrder number: ${job.order_number}\n\nYour request is awaiting inventory and owner approval. This email is not an approval or payment confirmation. Please do not send payment yet.\n\nAfter approval, we will email the final total and payment instructions. Include your order number as the payment reference and send payment only once.\n\nView your request and its status in your client portal:\n${portal}\n\nQuestions? Reply to this email.\n\nMirai Labs\n${OWNER}\nFor laboratory research use only. Not for human or animal consumption.`
  };
  if(job.kind!=='shipped' || !job.tracking_number || /[\r\n]/.test(job.tracking_number)) throw Error('Invalid shipment');
  const tracking=new URL(job.tracking_url);if(tracking.protocol!=='https:' || tracking.username || tracking.password)throw Error('Invalid tracking URL');
  return {subject:`Mirai Labs: order ${job.order_number} shipping update`,text:`Your order has been marked shipped by Mirai Labs.\n\nOrder number: ${job.order_number}\nTracking number: ${job.tracking_number}\nTrack your shipment: ${tracking.href}\n\nTracking may take time to appear after the carrier scans the package. You can also view tracking in your client portal:\n${portal}\n\nIf anything arrives damaged or incorrect, keep the packaging and photos and contact us promptly with your order number.\n\nQuestions? Reply to this email.\n\nMirai Labs\n${OWNER}\nFor laboratory research use only. Not for human or animal consumption.`};
}
export function notificationMessage(job: any) {
  const portal='https://mirailabshealth.github.io/mirai-labs/portal.html';
  const footer=`\n\nMirai Labs\nQuestions? Reply to this email.\nFor laboratory research use only. Not for human or animal consumption.`;
  let subject: string, text: string;
  switch(job.kind) {
    case 'affiliate_received':
      subject='Mirai Labs: affiliate application received';
      text='We received your affiliate application. An owner will review it and email you a decision. Your application is not approved yet. Please do not submit it again. No payment is required to apply.';break;
    case 'owner_affiliate':
      subject='Mirai Labs: affiliate application needs review';
      text=`A new affiliate application is awaiting your review. Sign in to the owner portal and open Affiliates.\n\n${portal}?view=admin\n\nReview the profile and audience details before approving or declining. Your decision queues an email to the applicant. This alert does not approve the application.`;break;
    case 'affiliate_approved':
      subject='Mirai Labs: your affiliate application is approved';
      text=job.source==='public' ? `Your affiliate application has been approved. Complete these steps to activate your partnership:\n\n1. Create an account, or sign in, using the same email address where you received this message.\n2. Verify that email and complete your account details.\n3. Open the Affiliate portal and choose your permanent affiliate code. You can choose it only once; it cannot be changed.\n\n${portal}?view=affiliate\n\nYour code becomes usable after activation. Commission applies to eligible paid product revenue under the partner terms; approval alone does not create earnings.` : `Your affiliate application has been approved. Sign in to the Affiliate portal to view your permanent code, referrals and commission status.\n\n${portal}?view=affiliate\n\nCommission applies to eligible paid product revenue under the partner terms; approval alone does not create earnings.`;break;
    case 'affiliate_rejected':
      subject='Mirai Labs: affiliate application update';
      text='Thank you for your interest in Mirai Labs. We are not approving your affiliate application at this time. If you have questions about this decision, reply to this email.';break;
    case 'owner_payment':
    case 'owner_order':
      if (!/^MIR-[0-9]+$/.test(job.order_number || '')) throw Error('Invalid order number');
      subject=`Mirai Labs: ${job.order_number} ${job.kind==='owner_payment'?'payment needs verification':'needs approval'}`;
      text=job.kind==='owner_payment' ? `A customer submitted payment details for order ${job.order_number}. This is a customer report, not proof of payment. Check the actual deposit in your payment account before marking paid.\n\n${portal}?view=admin` : `Order ${job.order_number} is awaiting your review. Check inventory and shipping details before approving. Approval triggers payment instructions; it does not confirm payment.\n\n${portal}?view=admin`;break;
    case 'notification_test':
      subject='Mirai Labs: notification delivery test';
      text='This is a notification delivery test. No customer application or order was created, approved or paid.';break;
    default: throw Error('Invalid notification');
  }
  return {subject,text:text+footer};
}

const OWNER='mirai.labs.health@gmail.com';
for (const kind of ['affiliate_received','owner_affiliate','affiliate_approved','affiliate_rejected','owner_payment','owner_order','notification_test']) {
 const m=notificationMessage({kind,source:'public',order_number:'MIR-1001'});
 if(!m.subject || !m.text || /undefined/.test(m.text))throw Error(kind);
}
if(!notificationMessage({kind:'affiliate_approved',source:'public'}).text.includes('only once'))throw Error('Missing permanent-code instructions');
if(!notificationMessage({kind:'owner_payment',order_number:'MIR-1001'}).text.includes('not proof'))throw Error('Missing verification warning');
let rejected=false;try{notificationMessage({kind:'owner_payment',order_number:'invalid'})}catch{rejected=true}if(!rejected)throw Error('Unsafe order number');
console.log('PASS: seven notification templates, activation instructions, payment distinction, invalid order rejection');
